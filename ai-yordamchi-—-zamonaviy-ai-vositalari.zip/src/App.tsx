/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { Hero } from './components/Hero';
import { ToolGrid } from './components/ToolGrid';
import { HistoryModal } from './components/HistoryModal';
import { ProfileModal } from './components/ProfileModal';

// Tools
import { StickerTool } from './components/tools/StickerTool';
import { ObjectDetectorTool } from './components/tools/ObjectDetectorTool';
import { RepairAssistantTool } from './components/tools/RepairAssistantTool';
import { QRCodeTool } from './components/tools/QRCodeTool';
import { MathSolverTool } from './components/tools/MathSolverTool';
import { SubtitleTool } from './components/tools/SubtitleTool';

import { ToolId, HistoryItem } from './types';
import { historyService } from './services/historyService';
import { Sparkles, Heart } from 'lucide-react';

export default function App() {
  const [currentTab, setCurrentTab] = useState<'home' | 'tools' | 'tool-view' | 'history'>('home');
  const [activeToolId, setActiveToolId] = useState<ToolId | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');
  
  // Modals
  const [isHistoryOpen, setIsHistoryOpen] = useState<boolean>(false);
  const [isProfileOpen, setIsProfileOpen] = useState<boolean>(false);

  // Favorites & History state
  const [favorites, setFavorites] = useState<ToolId[]>(() => historyService.getFavorites());
  const [historyCount, setHistoryCount] = useState<number>(() => historyService.getHistory().length);

  const refreshCounts = () => {
    setFavorites(historyService.getFavorites());
    setHistoryCount(historyService.getHistory().length);
  };

  const handleToggleFavorite = (toolId: ToolId) => {
    historyService.toggleFavorite(toolId);
    refreshCounts();
  };

  const handleSelectTool = (id: ToolId) => {
    setActiveToolId(id);
    setCurrentTab('tool-view');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBackToTools = () => {
    setActiveToolId(null);
    setCurrentTab('tools');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleStartTools = () => {
    setActiveToolId(null);
    setCurrentTab('tools');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenHistoryItem = (item: HistoryItem) => {
    handleSelectTool(item.toolId);
  };

  const renderActiveTool = () => {
    switch (activeToolId) {
      case 'sticker':
        return <StickerTool onBack={handleBackToTools} />;
      case 'object_detector':
        return <ObjectDetectorTool onBack={handleBackToTools} />;
      case 'repair':
        return <RepairAssistantTool onBack={handleBackToTools} />;
      case 'qrcode':
        return <QRCodeTool onBack={handleBackToTools} />;
      case 'math':
        return <MathSolverTool onBack={handleBackToTools} />;
      case 'subtitles':
        return <SubtitleTool onBack={handleBackToTools} />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-[#0b0f19] text-slate-100 flex flex-col font-sans selection:bg-purple-600/30 selection:text-purple-200">
      
      {/* Top Header */}
      <Header
        currentTab={currentTab}
        onNavigate={(tab) => {
          if (tab === 'history') {
            setIsHistoryOpen(true);
          } else {
            setActiveToolId(null);
            setCurrentTab(tab);
          }
        }}
        searchQuery={searchQuery}
        onSearchChange={(q) => {
          setSearchQuery(q);
          if (q && currentTab === 'home') {
            setCurrentTab('tools');
          }
        }}
        historyCount={historyCount}
        favoriteCount={favorites.length}
        onOpenProfile={() => setIsProfileOpen(true)}
      />

      {/* Main Container */}
      <main className="flex-1 pb-20 lg:pb-12">
        {currentTab === 'home' && !activeToolId && (
          <>
            <Hero
              onStartTools={handleStartTools}
              onExploreDemo={(id) => handleSelectTool(id || 'sticker')}
            />
            <ToolGrid
              onSelectTool={handleSelectTool}
              searchQuery={searchQuery}
              onSearchChange={setSearchQuery}
              favorites={favorites}
              onToggleFavorite={handleToggleFavorite}
            />
          </>
        )}

        {currentTab === 'tools' && !activeToolId && (
          <div className="pt-6">
            <ToolGrid
              onSelectTool={handleSelectTool}
              searchQuery={searchQuery}
              onSearchChange={setSearchQuery}
              favorites={favorites}
              onToggleFavorite={handleToggleFavorite}
            />
          </div>
        )}

        {activeToolId && (
          <div className="animate-in fade-in duration-200">
            {renderActiveTool()}
          </div>
        )}
      </main>

      {/* Modern Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-950/60 py-8 px-4 sm:px-6 lg:px-8 text-center text-xs text-slate-400">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg bg-purple-600/30 flex items-center justify-center text-purple-400 font-bold text-xs">
              AI
            </div>
            <span className="font-bold text-slate-200">AI Yordamchi</span>
            <span>— O'zbekistondagi kundalik AI vositalar to'plami.</span>
          </div>

          <div className="flex items-center gap-1 text-slate-400">
            <span>O'zbek tilida tayyorlandi</span>
            <span className="text-pink-500 font-bold">♥</span>
            <span className="ml-2 font-mono text-[11px] text-slate-500">v2.5 Pro</span>
          </div>
        </div>
      </footer>

      {/* Mobile Bottom Navigation */}
      <BottomNav
        currentTab={currentTab}
        onNavigate={(tab) => {
          if (tab === 'history') {
            setIsHistoryOpen(true);
          } else {
            setActiveToolId(null);
            setCurrentTab(tab);
          }
        }}
        onOpenProfile={() => setIsProfileOpen(true)}
        historyCount={historyCount}
      />

      {/* History Modal */}
      <HistoryModal
        isOpen={isHistoryOpen}
        onClose={() => {
          setIsHistoryOpen(false);
          refreshCounts();
        }}
        onOpenItem={handleOpenHistoryItem}
      />

      {/* Profile Modal */}
      <ProfileModal
        isOpen={isProfileOpen}
        onClose={() => setIsProfileOpen(false)}
        onOpenHistory={() => setIsHistoryOpen(true)}
      />

    </div>
  );
}
