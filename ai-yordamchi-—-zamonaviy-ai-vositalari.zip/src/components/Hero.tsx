import React from 'react';
import { 
  Sparkles, 
  ArrowRight, 
  Play, 
  CheckCircle2, 
  ShieldCheck, 
  Zap, 
  Languages 
} from 'lucide-react';
import { ToolId } from '../types';

interface HeroProps {
  onStartTools: () => void;
  onExploreDemo: (toolId?: ToolId) => void;
}

export const Hero: React.FC<HeroProps> = ({ onStartTools, onExploreDemo }) => {
  return (
    <section className="relative overflow-hidden pt-8 pb-14 sm:pt-14 sm:pb-20">
      {/* Background glowing gradients */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[550px] sm:w-[750px] h-[350px] sm:h-[450px] bg-gradient-to-tr from-purple-700/25 via-indigo-600/20 to-pink-500/20 blur-[120px] rounded-full pointer-events-none -z-10 animate-pulse-glow" />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 text-center">
        {/* Pill Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-purple-500/10 border border-purple-500/20 text-purple-300 text-xs sm:text-sm font-medium mb-6 backdrop-blur-md shadow-inner">
          <Sparkles className="w-4 h-4 text-purple-400" />
          <span>O'zbekistondagi eng qulay sun'iy intellekt platformasi</span>
        </div>

        {/* Hero Title */}
        <h1 className="text-3xl sm:text-5xl md:text-6xl font-extrabold tracking-tight text-white mb-6 leading-[1.15]">
          Barcha AI vositalari —{' '}
          <span className="bg-gradient-to-r from-purple-400 via-pink-400 to-amber-300 bg-clip-text text-transparent">
            bitta joyda 🤖
          </span>
        </h1>

        {/* Subtitle */}
        <p className="text-base sm:text-lg md:text-xl text-slate-300 max-w-3xl mx-auto mb-9 leading-relaxed font-normal">
          Rasmni tahlil qiling, sticker yarating, masala yeching, QR kod yarating, videoga subtitr qo‘shing va yana ko‘p ishlarni bajaring.
        </p>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3.5 sm:gap-4 mb-12">
          <button
            onClick={onStartTools}
            className="w-full sm:w-auto px-7 py-3.5 rounded-2xl bg-gradient-to-r from-purple-600 via-indigo-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white font-semibold text-sm sm:text-base shadow-xl shadow-purple-600/30 hover:shadow-purple-600/50 flex items-center justify-center gap-2 group transition-all duration-300 hover:scale-[1.02] active:scale-[0.98]"
          >
            <span>AI vositalarini boshlash</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>

          <button
            onClick={() => onExploreDemo('sticker')}
            className="w-full sm:w-auto px-7 py-3.5 rounded-2xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700/80 hover:border-purple-500/50 text-slate-200 hover:text-white font-medium text-sm sm:text-base backdrop-blur-md flex items-center justify-center gap-2 transition-all duration-200 hover:scale-[1.02] active:scale-[0.98]"
          >
            <Play className="w-4 h-4 text-purple-400 fill-purple-400/20" />
            <span>Demo ko‘rish</span>
          </button>
        </div>

        {/* Key Features Highlights */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4 max-w-4xl mx-auto pt-4 border-t border-slate-800/80 text-left">
          <div className="flex items-center gap-2.5 p-3 rounded-xl bg-slate-900/40 border border-slate-800/50">
            <Languages className="w-5 h-5 text-purple-400 flex-shrink-0" />
            <div>
              <p className="text-xs font-semibold text-white">100% O'zbek tilida</p>
              <p className="text-[11px] text-slate-400">Raqamli qulaylik</p>
            </div>
          </div>

          <div className="flex items-center gap-2.5 p-3 rounded-xl bg-slate-900/40 border border-slate-800/50">
            <Zap className="w-5 h-5 text-amber-400 flex-shrink-0" />
            <div>
              <p className="text-xs font-semibold text-white">Tezkor natija</p>
              <p className="text-[11px] text-slate-400">Soniyalar ichida</p>
            </div>
          </div>

          <div className="flex items-center gap-2.5 p-3 rounded-xl bg-slate-900/40 border border-slate-800/50">
            <ShieldCheck className="w-5 h-5 text-emerald-400 flex-shrink-0" />
            <div>
              <p className="text-xs font-semibold text-white">Maxfiylik himoyasi</p>
              <p className="text-[11px] text-slate-400">Fayllar xavfsiz</p>
            </div>
          </div>

          <div className="flex items-center gap-2.5 p-3 rounded-xl bg-slate-900/40 border border-slate-800/50">
            <CheckCircle2 className="w-5 h-5 text-blue-400 flex-shrink-0" />
            <div>
              <p className="text-xs font-semibold text-white">6 ta kuchli vosita</p>
              <p className="text-[11px] text-slate-400">Barchasi bepul</p>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
