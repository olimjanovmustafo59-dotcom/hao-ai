import React from 'react';
import { Home, Layers, Clock, User } from 'lucide-react';

interface BottomNavProps {
  currentTab: 'home' | 'tools' | 'tool-view' | 'history';
  onNavigate: (tab: 'home' | 'tools' | 'tool-view' | 'history') => void;
  onOpenProfile: () => void;
  historyCount: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  currentTab,
  onNavigate,
  onOpenProfile,
  historyCount,
}) => {
  return (
    <div className="lg:hidden fixed bottom-0 left-0 right-0 z-50 bg-[#0b0f19]/95 backdrop-blur-xl border-t border-white/10 px-2 py-1 safe-area-pb">
      <div className="grid grid-cols-4 max-w-md mx-auto">
        <button
          onClick={() => onNavigate('home')}
          className={`flex flex-col items-center justify-center py-2 px-1 rounded-xl transition-all ${
            currentTab === 'home'
              ? 'text-purple-400 font-semibold scale-105'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Home className="w-5 h-5 mb-0.5" />
          <span className="text-[11px]">Bosh sahifa</span>
        </button>

        <button
          onClick={() => onNavigate('tools')}
          className={`flex flex-col items-center justify-center py-2 px-1 rounded-xl transition-all ${
            currentTab === 'tools' || currentTab === 'tool-view'
              ? 'text-purple-400 font-semibold scale-105'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Layers className="w-5 h-5 mb-0.5" />
          <span className="text-[11px]">AI vositalari</span>
        </button>

        <button
          onClick={() => onNavigate('history')}
          className={`flex flex-col items-center justify-center py-2 px-1 rounded-xl relative transition-all ${
            currentTab === 'history'
              ? 'text-purple-400 font-semibold scale-105'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <div className="relative">
            <Clock className="w-5 h-5 mb-0.5" />
            {historyCount > 0 && (
              <span className="absolute -top-1 -right-2 w-4 h-4 bg-purple-600 text-white text-[9px] font-bold rounded-full flex items-center justify-center border border-[#0b0f19]">
                {historyCount > 9 ? '9+' : historyCount}
              </span>
            )}
          </div>
          <span className="text-[11px]">Tarix</span>
        </button>

        <button
          onClick={onOpenProfile}
          className="flex flex-col items-center justify-center py-2 px-1 rounded-xl text-slate-400 hover:text-slate-200 transition-all"
        >
          <User className="w-5 h-5 mb-0.5" />
          <span className="text-[11px]">Profil</span>
        </button>
      </div>
    </div>
  );
};
