import React from 'react';
import { 
  Sparkles, 
  Search, 
  Clock, 
  Star, 
  User, 
  Layers,
  Home
} from 'lucide-react';
import { ToolId } from '../types';

interface HeaderProps {
  currentTab: 'home' | 'tools' | 'tool-view' | 'history';
  onNavigate: (tab: 'home' | 'tools' | 'tool-view' | 'history') => void;
  onSelectTool?: (toolId: ToolId) => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  historyCount: number;
  favoriteCount: number;
  onOpenProfile: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  onNavigate,
  searchQuery,
  onSearchChange,
  historyCount,
  favoriteCount,
  onOpenProfile,
}) => {
  return (
    <header className="sticky top-0 z-40 w-full backdrop-blur-xl bg-[#0b0f19]/80 border-b border-white/10 transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 sm:h-20 flex items-center justify-between gap-4">
        
        {/* Brand / Logo */}
        <div 
          onClick={() => onNavigate('home')}
          className="flex items-center gap-3 cursor-pointer group select-none flex-shrink-0"
        >
          <div className="relative w-10 h-10 sm:w-11 sm:h-11 rounded-2xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-pink-500 p-0.5 shadow-lg shadow-purple-500/25 group-hover:scale-105 transition-transform duration-300">
            <div className="w-full h-full bg-[#0b0f19] rounded-[14px] flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-purple-400 group-hover:rotate-12 transition-transform duration-300" />
            </div>
            <span className="absolute -top-1 -right-1 w-3 h-3 bg-emerald-500 rounded-full border-2 border-[#0b0f19] animate-pulse"></span>
          </div>

          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-lg sm:text-xl tracking-tight bg-gradient-to-r from-white via-slate-100 to-slate-300 bg-clip-text text-transparent">
                AI Yordamchi
              </span>
              <span className="hidden sm:inline-block text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-purple-500/10 text-purple-300 border border-purple-500/20">
                PRO 🤖
              </span>
            </div>
            <p className="hidden md:block text-[11px] text-slate-400">
              Barcha aqlli vositalar bitta joyda
            </p>
          </div>
        </div>

        {/* Global Search Bar */}
        <div className="hidden md:flex flex-1 max-w-md mx-2">
          <div className="relative w-full">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="Qaysi AI vositasini qidiryapsiz? (masalan: sticker, matematika...)"
              className="w-full pl-10 pr-4 py-2 text-sm bg-slate-900/80 border border-slate-700/60 rounded-xl text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-purple-500/40 focus:border-purple-500/60 transition-all"
            />
            {searchQuery && (
              <button
                onClick={() => onSearchChange('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-white px-1.5 py-0.5 rounded bg-slate-800"
              >
                ✕
              </button>
            )}
          </div>
        </div>

        {/* Desktop Navigation Links */}
        <nav className="hidden lg:flex items-center gap-1 sm:gap-2">
          <button
            onClick={() => onNavigate('home')}
            className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-medium transition-colors flex items-center gap-1.5 ${
              currentTab === 'home'
                ? 'bg-purple-600/20 text-purple-300 border border-purple-500/30'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <Home className="w-4 h-4" />
            Bosh sahifa
          </button>

          <button
            onClick={() => onNavigate('tools')}
            className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-medium transition-colors flex items-center gap-1.5 ${
              currentTab === 'tools'
                ? 'bg-purple-600/20 text-purple-300 border border-purple-500/30'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <Layers className="w-4 h-4" />
            AI vositalari
          </button>

          <button
            onClick={() => onNavigate('tools')}
            className="px-3.5 py-2 rounded-xl text-xs sm:text-sm font-medium text-slate-300 hover:text-white hover:bg-slate-800/60 transition-colors flex items-center gap-1.5"
            title="Sevimlilar bo'yicha saralash"
          >
            <Star className="w-4 h-4 text-amber-400 fill-amber-400/20" />
            <span>Sevimlilar</span>
            {favoriteCount > 0 && (
              <span className="text-[10px] px-1.5 py-0.2 bg-amber-500/20 text-amber-300 font-bold rounded-full">
                {favoriteCount}
              </span>
            )}
          </button>

          <button
            onClick={() => onNavigate('history')}
            className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-medium transition-colors flex items-center gap-1.5 ${
              currentTab === 'history'
                ? 'bg-purple-600/20 text-purple-300 border border-purple-500/30'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <Clock className="w-4 h-4 text-blue-400" />
            <span>Tarix</span>
            {historyCount > 0 && (
              <span className="text-[10px] px-1.5 py-0.2 bg-blue-500/20 text-blue-300 font-bold rounded-full">
                {historyCount}
              </span>
            )}
          </button>
        </nav>

        {/* Right side Profile button & Demo mode tag */}
        <div className="flex items-center gap-2 sm:gap-3">
          <button
            onClick={onOpenProfile}
            className="flex items-center gap-2 p-1.5 sm:px-3 sm:py-2 rounded-xl bg-slate-900/80 hover:bg-slate-800/90 border border-slate-700/60 text-slate-200 hover:text-white transition-all text-xs sm:text-sm font-medium"
            title="Foydalanuvchi profili va sozlamalar"
          >
            <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-purple-500 to-indigo-500 flex items-center justify-center text-white text-xs font-bold">
              U
            </div>
            <span className="hidden sm:inline">Profil</span>
          </button>
        </div>

      </div>

      {/* Mobile Search input bar */}
      <div className="md:hidden px-4 pb-3">
        <div className="relative w-full">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Qaysi AI vositasini qidiryapsiz?..."
            className="w-full pl-9 pr-4 py-2 text-xs bg-slate-900 border border-slate-800 rounded-lg text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-purple-500"
          />
          {searchQuery && (
            <button
              onClick={() => onSearchChange('')}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-xs text-slate-400 px-1"
            >
              ✕
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
