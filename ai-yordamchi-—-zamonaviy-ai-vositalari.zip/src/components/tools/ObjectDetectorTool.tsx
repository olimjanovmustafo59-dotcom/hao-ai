import React, { useState, useRef } from 'react';
import { 
  Upload, 
  Sparkles, 
  Volume2, 
  VolumeX, 
  CheckCircle2, 
  AlertTriangle, 
  Tag, 
  Lightbulb, 
  RefreshCw, 
  Camera, 
  FileText 
} from 'lucide-react';
import { aiService } from '../../services/aiService';
import { historyService } from '../../services/historyService';
import { SAMPLE_IMAGES } from '../../services/sampleMedia';
import { ObjectAnalysisResult } from '../../types';

interface ObjectDetectorToolProps {
  onBack: () => void;
}

export const ObjectDetectorTool: React.FC<ObjectDetectorToolProps> = ({ onBack }) => {
  const [imageSrc, setImageSrc] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [result, setResult] = useState<ObjectAnalysisResult | null>(null);
  const [isPlayingAudio, setIsPlayingAudio] = useState<boolean>(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      setImageSrc(dataUrl);
      runAnalysis(dataUrl);
    };
    reader.readAsDataURL(file);
  };

  const handleSampleSelect = (type: 'screwdriver' | 'cat') => {
    const sample = type === 'screwdriver' ? SAMPLE_IMAGES.screwdriver : SAMPLE_IMAGES.cuteCat;
    setImageSrc(sample);
    runAnalysis(sample);
  };

  const runAnalysis = async (img: string) => {
    setIsAnalyzing(true);
    setResult(null);
    stopAudio();

    try {
      const res = await aiService.analyzeImage(img);
      setResult(res);

      // Save to history
      historyService.addHistory({
        toolId: 'object_detector',
        title: res.objectName || "Aniqlangan obyekt",
        previewText: res.usage,
        thumbnailUrl: img,
        data: res,
      });
    } catch (err) {
      console.error('Detection error:', err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Text-to-speech functionality in Uzbek / browser speech synthesis
  const toggleSpeech = () => {
    if (!result) return;

    if (isPlayingAudio) {
      stopAudio();
      return;
    }

    if ('speechSynthesis' in window) {
      const textToRead = result.audioText || `${result.objectName}. ${result.usage}. ${result.interestingFact}`;
      const utterance = new SpeechSynthesisUtterance(textToRead);
      utterance.lang = 'uz-UZ';
      utterance.rate = 0.95;

      utterance.onend = () => setIsPlayingAudio(false);
      utterance.onerror = () => setIsPlayingAudio(false);

      window.speechSynthesis.cancel();
      window.speechSynthesis.speak(utterance);
      setIsPlayingAudio(true);
    } else {
      alert("Kechirasiz, brauzeringizda ovozli o'qish imkoniyati qo'llab-quvvatlanmaydi.");
    }
  };

  const stopAudio = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setIsPlayingAudio(false);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      
      {/* Header */}
      <div className="flex items-center justify-between pb-6 mb-6 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 hover:bg-slate-800 text-slate-300 text-sm font-medium transition-colors"
          >
            ← Orqaga
          </button>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-2xl">🔍</span>
              <h1 className="text-xl sm:text-2xl font-bold text-white">Bu nima? — AI Object Detector</h1>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-500/20 text-blue-300 border border-blue-500/30">
                Vision AI
              </span>
            </div>
            <p className="text-xs sm:text-sm text-slate-400">
              Rasmdagi har qanday narsa, asbob yoki buyumni aniqlang va to'liq o'zbek tilida ma'lumot oling.
            </p>
          </div>
        </div>

        {result && (
          <button
            onClick={() => {
              setImageSrc(null);
              setResult(null);
              stopAudio();
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs text-slate-300 transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Yangi rasm tekshirish</span>
          </button>
        )}
      </div>

      {/* Main Content Area */}
      {!imageSrc ? (
        <div className="max-w-2xl mx-auto py-10">
          <div
            onClick={() => fileInputRef.current?.click()}
            className="group relative flex flex-col items-center justify-center p-12 border-2 border-dashed border-slate-700 hover:border-blue-500 rounded-3xl bg-slate-900/50 hover:bg-slate-900/80 transition-all duration-300 cursor-pointer text-center"
          >
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleFileUpload}
            />

            <div className="w-20 h-20 rounded-3xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-4xl mb-6 group-hover:scale-110 transition-transform">
              🔍
            </div>

            <h3 className="text-xl font-bold text-white mb-2">
              Buyum rasmini yuklang yoki kameradan oling
            </h3>
            <p className="text-sm text-slate-400 max-w-md mb-6">
              AI tasvirni chuqur tahlil qiladi, uning nimaligini, vazifasini, xususiyatlarini va xavfsizlik qoidalarini taqdim etadi.
            </p>

            <div className="flex flex-wrap items-center justify-center gap-3">
              <button
                type="button"
                className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs sm:text-sm font-semibold shadow-lg shadow-blue-600/30 flex items-center gap-2"
              >
                <Upload className="w-4 h-4" />
                <span>Rasm tanlash</span>
              </button>

              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  handleSampleSelect('screwdriver');
                }}
                className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs sm:text-sm font-medium flex items-center gap-2"
              >
                <Sparkles className="w-4 h-4 text-cyan-400" />
                <span>Namuna: Otvyortka</span>
              </button>
            </div>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Column: Image preview & Voice Readout */}
          <div className="lg:col-span-5 space-y-4">
            <div className="relative rounded-3xl overflow-hidden bg-slate-900 border border-slate-800 shadow-2xl p-3">
              <img
                src={imageSrc}
                alt="Yuklangan obyekt"
                className="w-full h-80 object-contain rounded-2xl bg-black/40"
              />

              {isAnalyzing && (
                <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center">
                  <div className="relative w-16 h-16 mb-4">
                    <div className="w-16 h-16 rounded-full border-4 border-blue-500/20 border-t-blue-500 animate-spin" />
                    <Sparkles className="w-6 h-6 text-blue-400 absolute inset-0 m-auto" />
                  </div>
                  <h4 className="text-white font-bold text-base mb-1">
                    AI tasvirni tahlil qilmoqda...
                  </h4>
                  <p className="text-xs text-slate-400">
                    Obyekt parametrlari va foydalanish maqsadi aniqlanmoqda
                  </p>
                </div>
              )}
            </div>

            {/* Read Aloud Button */}
            {result && (
              <button
                onClick={toggleSpeech}
                className={`w-full py-3.5 px-4 rounded-2xl font-bold text-sm flex items-center justify-center gap-2.5 transition-all shadow-lg ${
                  isPlayingAudio
                    ? 'bg-rose-600 hover:bg-rose-500 text-white shadow-rose-600/30 animate-pulse'
                    : 'bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white shadow-blue-600/30'
                }`}
              >
                {isPlayingAudio ? (
                  <>
                    <VolumeX className="w-5 h-5" />
                    <span>Ovozni to'xtatish</span>
                  </>
                ) : (
                  <>
                    <Volume2 className="w-5 h-5" />
                    <span>🔊 Ovozli o‘qish</span>
                  </>
                )}
              </button>
            )}

            <button
              onClick={() => {
                setImageSrc(null);
                setResult(null);
                stopAudio();
              }}
              className="w-full py-2.5 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 text-xs font-semibold flex items-center justify-center gap-2 transition-colors"
            >
              <Camera className="w-4 h-4" />
              <span>Boshqa rasm yuklash</span>
            </button>
          </div>

          {/* Right Column: AI Analysis Result in Uzbek */}
          <div className="lg:col-span-7 space-y-5">
            {isAnalyzing && (
              <div className="p-8 rounded-3xl bg-slate-900/60 border border-slate-800 animate-pulse space-y-4">
                <div className="h-7 bg-slate-800 rounded-xl w-3/4" />
                <div className="h-4 bg-slate-800 rounded-lg w-full" />
                <div className="h-4 bg-slate-800 rounded-lg w-5/6" />
                <div className="h-24 bg-slate-800 rounded-2xl w-full mt-4" />
              </div>
            )}

            {result && !isAnalyzing && (
              <div className="space-y-4 animate-in fade-in slide-in-from-bottom-2 duration-300">
                
                {/* Bu nima? Card */}
                <div className="p-6 rounded-3xl bg-slate-900/80 border border-blue-500/30 shadow-xl relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/10 rounded-full blur-2xl pointer-events-none" />
                  
                  <span className="text-[11px] font-extrabold uppercase tracking-wider text-blue-400 block mb-1">
                    Bu nima?
                  </span>
                  <h2 className="text-2xl sm:text-3xl font-extrabold text-white mb-2">
                    "{result.objectName}"
                  </h2>
                  <p className="text-sm text-slate-300 leading-relaxed">
                    {result.usage}
                  </p>
                </div>

                {/* Characteristics */}
                <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800">
                  <div className="flex items-center gap-2 mb-3">
                    <Tag className="w-4 h-4 text-purple-400" />
                    <h3 className="text-xs font-bold uppercase tracking-wider text-purple-300">
                      Asosiy xususiyatlari
                    </h3>
                  </div>
                  <ul className="space-y-2">
                    {result.characteristics.map((c, i) => (
                      <li key={i} className="flex items-start gap-2 text-xs sm:text-sm text-slate-300">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
                        <span>{c}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Brand / Model / Category */}
                {result.brandOrModel && (
                  <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800">
                    <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                      Kategoriya va taxminiy model:
                    </span>
                    <p className="text-sm font-semibold text-slate-200">
                      {result.brandOrModel}
                    </p>
                  </div>
                )}

                {/* Interesting Fact */}
                {result.interestingFact && (
                  <div className="p-5 rounded-2xl bg-amber-500/10 border border-amber-500/30">
                    <div className="flex items-center gap-2 mb-2">
                      <Lightbulb className="w-4 h-4 text-amber-400" />
                      <h4 className="text-xs font-bold uppercase tracking-wider text-amber-300">
                        Qiziqarli ma'lumot
                      </h4>
                    </div>
                    <p className="text-xs sm:text-sm text-amber-100/90 leading-relaxed">
                      {result.interestingFact}
                    </p>
                  </div>
                )}

                {/* Safety Information */}
                {result.safetyInfo && (
                  <div className="p-5 rounded-2xl bg-rose-500/10 border border-rose-500/30">
                    <div className="flex items-center gap-2 mb-2">
                      <AlertTriangle className="w-4 h-4 text-rose-400" />
                      <h4 className="text-xs font-bold uppercase tracking-wider text-rose-300">
                        Xavfsizlik qoidalari
                      </h4>
                    </div>
                    <p className="text-xs sm:text-sm text-rose-100/90 leading-relaxed">
                      {result.safetyInfo}
                    </p>
                  </div>
                )}

              </div>
            )}
          </div>

        </div>
      )}

    </div>
  );
};
