import React, { useState, useEffect, useRef } from 'react';
import { 
  Download, 
  Sparkles, 
  Globe, 
  FileText, 
  Phone, 
  Mail, 
  Wifi, 
  Send, 
  Instagram, 
  Youtube, 
  UserCheck, 
  Check, 
  Copy, 
  Sliders,
  RefreshCw
} from 'lucide-react';
import QRCode from 'qrcode';
import { historyService } from '../../services/historyService';

interface QRCodeToolProps {
  onBack: () => void;
}

type QRType = 'url' | 'text' | 'phone' | 'email' | 'wifi' | 'telegram' | 'instagram' | 'youtube' | 'vcard';

export const QRCodeTool: React.FC<QRCodeToolProps> = ({ onBack }) => {
  const [activeType, setActiveType] = useState<QRType>('url');
  
  // Input fields
  const [urlInput, setUrlInput] = useState<string>('https://kun.uz');
  const [textInput, setTextInput] = useState<string>('Salom, bu AI Yordamchi platformasidan maxsus QR kod!');
  const [phoneInput, setPhoneInput] = useState<string>('+998901234567');
  const [emailInput, setEmailInput] = useState<string>('info@example.uz');
  const [emailSubject, setEmailSubject] = useState<string>('Aloqa');
  
  // Wi-Fi fields
  const [wifiSsid, setWifiSsid] = useState<string>('Mening_WiFi_Tarmogim');
  const [wifiPassword, setWifiPassword] = useState<string>('Parol12345');
  const [wifiEncryption, setWifiEncryption] = useState<'WPA' | 'WEP' | 'nopass'>('WPA');

  // Socials
  const [tgUsername, setTgUsername] = useState<string>('daryo');
  const [igUsername, setIgUsername] = useState<string>('kun.uz');
  const [ytUrl, setYtUrl] = useState<string>('https://youtube.com/@uzbekistan');

  // vCard fields
  const [vcardName, setVcardName] = useState<string>('Alisher Navoiy');
  const [vcardPhone, setVcardPhone] = useState<string>('+998901234567');
  const [vcardOrg, setVcardOrg] = useState<string>('IT Park Uzbekistan');

  // QR Customization
  const [qrColor, setQrColor] = useState<string>('#0f172a');
  const [bgColor, setBgColor] = useState<string>('#ffffff');
  const [size, setSize] = useState<number>(512);
  const [errorCorrection, setErrorCorrection] = useState<'L' | 'M' | 'Q' | 'H'>('H');
  const [centerLogo, setCenterLogo] = useState<'none' | 'telegram' | 'instagram' | 'wifi' | 'web' | 'star'>('none');
  const [copied, setCopied] = useState<boolean>(false);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Compute final QR content payload based on active type
  const getPayload = (): string => {
    switch (activeType) {
      case 'url':
        return urlInput.startsWith('http') ? urlInput : `https://${urlInput}`;
      case 'text':
        return textInput;
      case 'phone':
        return `tel:${phoneInput.replace(/\s+/g, '')}`;
      case 'email':
        return `mailto:${emailInput}?subject=${encodeURIComponent(emailSubject)}`;
      case 'wifi':
        return `WIFI:S:${wifiSsid};T:${wifiEncryption};P:${wifiPassword};;`;
      case 'telegram':
        const cleanTg = tgUsername.replace(/^@/, '');
        return `https://t.me/${cleanTg}`;
      case 'instagram':
        const cleanIg = igUsername.replace(/^@/, '');
        return `https://instagram.com/${cleanIg}`;
      case 'youtube':
        return ytUrl;
      case 'vcard':
        return `BEGIN:VCARD\nVERSION:3.0\nN:${vcardName}\nFN:${vcardName}\nORG:${vcardOrg}\nTEL:${vcardPhone}\nEND:VCARD`;
      default:
        return 'https://ai-yordamchi.uz';
    }
  };

  // Generate real-time QR on canvas
  const renderQRCode = async () => {
    if (!canvasRef.current) return;
    const canvas = canvasRef.current;
    const payload = getPayload() || 'https://ai-yordamchi.uz';

    try {
      await QRCode.toCanvas(canvas, payload, {
        width: 320,
        margin: 2,
        errorCorrectionLevel: errorCorrection,
        color: {
          dark: qrColor,
          light: bgColor,
        },
      });

      // Draw center icon if selected
      if (centerLogo !== 'none') {
        const ctx = canvas.getContext('2d');
        if (ctx) {
          const centerX = canvas.width / 2;
          const centerY = canvas.height / 2;
          const badgeSize = 56;

          // Draw rounded badge background
          ctx.fillStyle = bgColor;
          ctx.beginPath();
          ctx.arc(centerX, centerY, badgeSize / 2, 0, Math.PI * 2);
          ctx.fill();

          ctx.strokeStyle = qrColor;
          ctx.lineWidth = 3;
          ctx.stroke();

          // Emoji / Icon representation
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.font = '26px sans-serif';

          let iconChar = '🌐';
          if (centerLogo === 'telegram') iconChar = '✈️';
          if (centerLogo === 'instagram') iconChar = '📸';
          if (centerLogo === 'wifi') iconChar = '📶';
          if (centerLogo === 'star') iconChar = '⭐';

          ctx.fillText(iconChar, centerX, centerY + 1);
        }
      }
    } catch (e) {
      console.error('QR render error:', e);
    }
  };

  useEffect(() => {
    renderQRCode();
  }, [
    activeType,
    urlInput,
    textInput,
    phoneInput,
    emailInput,
    emailSubject,
    wifiSsid,
    wifiPassword,
    wifiEncryption,
    tgUsername,
    igUsername,
    ytUrl,
    vcardName,
    vcardPhone,
    vcardOrg,
    qrColor,
    bgColor,
    size,
    errorCorrection,
    centerLogo,
  ]);

  const handleDownloadPNG = async () => {
    const payload = getPayload();
    // Render full requested size off-screen
    const offCanvas = document.createElement('canvas');
    await QRCode.toCanvas(offCanvas, payload, {
      width: size,
      margin: 2,
      errorCorrectionLevel: errorCorrection,
      color: {
        dark: qrColor,
        light: bgColor,
      },
    });

    if (centerLogo !== 'none') {
      const ctx = offCanvas.getContext('2d');
      if (ctx) {
        const centerX = offCanvas.width / 2;
        const centerY = offCanvas.height / 2;
        const badgeSize = size * 0.18;

        ctx.fillStyle = bgColor;
        ctx.beginPath();
        ctx.arc(centerX, centerY, badgeSize / 2, 0, Math.PI * 2);
        ctx.fill();

        ctx.strokeStyle = qrColor;
        ctx.lineWidth = Math.max(3, size * 0.01);
        ctx.stroke();

        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.font = `${Math.round(badgeSize * 0.55)}px sans-serif`;

        let iconChar = '🌐';
        if (centerLogo === 'telegram') iconChar = '✈️';
        if (centerLogo === 'instagram') iconChar = '📸';
        if (centerLogo === 'wifi') iconChar = '📶';
        if (centerLogo === 'star') iconChar = '⭐';

        ctx.fillText(iconChar, centerX, centerY + 2);
      }
    }

    const dataUrl = offCanvas.toDataURL('image/png');
    const a = document.createElement('a');
    a.href = dataUrl;
    a.download = `qrcode_${activeType}_${Date.now()}.png`;
    a.click();

    // Save to history
    historyService.addHistory({
      toolId: 'qrcode',
      title: `QR Kod (${activeType.toUpperCase()})`,
      previewText: payload.length > 50 ? payload.substring(0, 50) + '...' : payload,
      thumbnailUrl: dataUrl,
      data: { activeType, payload, qrColor, bgColor },
    });
  };

  const handleDownloadSVG = async () => {
    const payload = getPayload();
    const svgString = await QRCode.toString(payload, {
      type: 'svg',
      width: size,
      margin: 2,
      errorCorrectionLevel: errorCorrection,
      color: {
        dark: qrColor,
        light: bgColor,
      },
    });

    const blob = new Blob([svgString], { type: 'image/svg+xml' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `qrcode_${activeType}_${Date.now()}.svg`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const typesList: { id: QRType; label: string; icon: any }[] = [
    { id: 'url', label: 'Veb-sayt', icon: Globe },
    { id: 'text', label: 'Oddiy matn', icon: FileText },
    { id: 'phone', label: 'Telefon', icon: Phone },
    { id: 'email', label: 'E-pochta', icon: Mail },
    { id: 'wifi', label: 'Wi-Fi Tarmoq', icon: Wifi },
    { id: 'telegram', label: 'Telegram', icon: Send },
    { id: 'instagram', label: 'Instagram', icon: Instagram },
    { id: 'youtube', label: 'YouTube', icon: Youtube },
    { id: 'vcard', label: 'Kontakt (vCard)', icon: UserCheck },
  ];

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      
      {/* Header */}
      <div className="flex items-center justify-between pb-6 mb-6 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 hover:bg-slate-800 text-slate-300 text-sm font-medium transition-colors"
          >
            ← Orqaga
          </button>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-2xl">📱</span>
              <h1 className="text-xl sm:text-2xl font-bold text-white">QR Code Generator</h1>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                Vector & PNG
              </span>
            </div>
            <p className="text-xs sm:text-sm text-slate-400">
              Veb-sayt, Wi-Fi, Telegram yoki vizitkalar uchun zamonaviy va chiroyli QR kod yarating.
            </p>
          </div>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Options / Inputs */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Type Selector Horizontal scroll / grid */}
          <div className="p-5 rounded-3xl bg-slate-900/80 border border-slate-800 shadow-xl">
            <label className="text-xs font-bold uppercase tracking-wider text-emerald-400 block mb-3">
              1. QR Kod turini tanlang:
            </label>
            <div className="grid grid-cols-3 sm:grid-cols-3 gap-2">
              {typesList.map((t) => {
                const Icon = t.icon;
                const isActive = activeType === t.id;

                return (
                  <button
                    key={t.id}
                    onClick={() => setActiveType(t.id)}
                    className={`flex items-center gap-2 p-3 rounded-2xl border text-left transition-all ${
                      isActive
                        ? 'bg-emerald-600/20 border-emerald-500 text-white shadow-lg shadow-emerald-950/40'
                        : 'bg-slate-800/40 border-slate-700/50 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <Icon className={`w-4 h-4 ${isActive ? 'text-emerald-400' : 'text-slate-500'}`} />
                    <span className="text-xs font-semibold">{t.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Dynamic Input Form */}
          <div className="p-5 rounded-3xl bg-slate-900/80 border border-slate-800 shadow-xl space-y-4">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-300 block">
              2. Ma'lumotlarni kiriting:
            </label>

            {activeType === 'url' && (
              <div>
                <span className="text-xs text-slate-400 block mb-1.5">Veb-sayt havolasi (URL):</span>
                <input
                  type="url"
                  value={urlInput}
                  onChange={(e) => setUrlInput(e.target.value)}
                  placeholder="https://example.uz"
                  className="w-full px-4 py-2.5 text-xs sm:text-sm bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
                />
              </div>
            )}

            {activeType === 'text' && (
              <div>
                <span className="text-xs text-slate-400 block mb-1.5">Matn:</span>
                <textarea
                  rows={3}
                  value={textInput}
                  onChange={(e) => setTextInput(e.target.value)}
                  placeholder="QR kodga aylanadigan xabarni yozing..."
                  className="w-full p-3 text-xs sm:text-sm bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
                />
              </div>
            )}

            {activeType === 'phone' && (
              <div>
                <span className="text-xs text-slate-400 block mb-1.5">Telefon raqami:</span>
                <input
                  type="tel"
                  value={phoneInput}
                  onChange={(e) => setPhoneInput(e.target.value)}
                  placeholder="+998 90 123 45 67"
                  className="w-full px-4 py-2.5 text-xs sm:text-sm bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
                />
              </div>
            )}

            {activeType === 'email' && (
              <div className="space-y-3">
                <div>
                  <span className="text-xs text-slate-400 block mb-1.5">Elektron pochta manzili:</span>
                  <input
                    type="email"
                    value={emailInput}
                    onChange={(e) => setEmailInput(e.target.value)}
                    placeholder="foydalanuvchi@mail.uz"
                    className="w-full px-4 py-2 text-xs sm:text-sm bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
                  />
                </div>
                <div>
                  <span className="text-xs text-slate-400 block mb-1.5">Xat mavzusi:</span>
                  <input
                    type="text"
                    value={emailSubject}
                    onChange={(e) => setEmailSubject(e.target.value)}
                    placeholder="Xat mavzusi"
                    className="w-full px-4 py-2 text-xs sm:text-sm bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
                  />
                </div>
              </div>
            )}

            {activeType === 'wifi' && (
              <div className="space-y-3">
                <div>
                  <span className="text-xs text-slate-400 block mb-1.5">Wi-Fi Tarmoq nomi (SSID):</span>
                  <input
                    type="text"
                    value={wifiSsid}
                    onChange={(e) => setWifiSsid(e.target.value)}
                    placeholder="Mening_WiFi"
                    className="w-full px-4 py-2 text-xs sm:text-sm bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
                  />
                </div>
                <div>
                  <span className="text-xs text-slate-400 block mb-1.5">Wi-Fi Paroli:</span>
                  <input
                    type="text"
                    value={wifiPassword}
                    onChange={(e) => setWifiPassword(e.target.value)}
                    placeholder="Parol..."
                    className="w-full px-4 py-2 text-xs sm:text-sm bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
                  />
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-400">Himoya turi:</span>
                  {(['WPA', 'WEP', 'nopass'] as const).map((enc) => (
                    <button
                      key={enc}
                      type="button"
                      onClick={() => setWifiEncryption(enc)}
                      className={`px-3 py-1 rounded-lg text-xs font-semibold ${
                        wifiEncryption === enc
                          ? 'bg-emerald-600 text-white'
                          : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {enc === 'nopass' ? 'Ochiq' : enc}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {activeType === 'telegram' && (
              <div>
                <span className="text-xs text-slate-400 block mb-1.5">Telegram Username yoki kanal:</span>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500">@</span>
                  <input
                    type="text"
                    value={tgUsername}
                    onChange={(e) => setTgUsername(e.target.value)}
                    placeholder="username"
                    className="w-full pl-8 pr-4 py-2.5 text-xs sm:text-sm bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
                  />
                </div>
              </div>
            )}

            {activeType === 'instagram' && (
              <div>
                <span className="text-xs text-slate-400 block mb-1.5">Instagram profil nomi:</span>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500">@</span>
                  <input
                    type="text"
                    value={igUsername}
                    onChange={(e) => setIgUsername(e.target.value)}
                    placeholder="username"
                    className="w-full pl-8 pr-4 py-2.5 text-xs sm:text-sm bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
                  />
                </div>
              </div>
            )}

            {activeType === 'youtube' && (
              <div>
                <span className="text-xs text-slate-400 block mb-1.5">YouTube video yoki kanal havolasi:</span>
                <input
                  type="url"
                  value={ytUrl}
                  onChange={(e) => setYtUrl(e.target.value)}
                  placeholder="https://youtube.com/..."
                  className="w-full px-4 py-2.5 text-xs sm:text-sm bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
                />
              </div>
            )}

            {activeType === 'vcard' && (
              <div className="space-y-3">
                <div>
                  <span className="text-xs text-slate-400 block mb-1">F.I.O (Ism va familiya):</span>
                  <input
                    type="text"
                    value={vcardName}
                    onChange={(e) => setVcardName(e.target.value)}
                    placeholder="Ism Familiya"
                    className="w-full px-4 py-2 text-xs sm:text-sm bg-slate-800 border border-slate-700 rounded-xl text-white"
                  />
                </div>
                <div>
                  <span className="text-xs text-slate-400 block mb-1">Telefon:</span>
                  <input
                    type="tel"
                    value={vcardPhone}
                    onChange={(e) => setVcardPhone(e.target.value)}
                    placeholder="+998 90 123 45 67"
                    className="w-full px-4 py-2 text-xs sm:text-sm bg-slate-800 border border-slate-700 rounded-xl text-white"
                  />
                </div>
                <div>
                  <span className="text-xs text-slate-400 block mb-1">Tashkilot / Lavozim:</span>
                  <input
                    type="text"
                    value={vcardOrg}
                    onChange={(e) => setVcardOrg(e.target.value)}
                    placeholder="Kompaniya nomi"
                    className="w-full px-4 py-2 text-xs sm:text-sm bg-slate-800 border border-slate-700 rounded-xl text-white"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Customization: Colors, Logo, Error correction */}
          <div className="p-5 rounded-3xl bg-slate-900/80 border border-slate-800 shadow-xl space-y-4">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-300 block">
              3. Ko'rinish va ranglar:
            </label>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <span className="text-xs text-slate-400 block mb-1.5">QR kodi rangi:</span>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={qrColor}
                    onChange={(e) => setQrColor(e.target.value)}
                    className="w-9 h-9 rounded-xl bg-transparent border-0 cursor-pointer"
                  />
                  <span className="text-xs font-mono text-slate-300 uppercase">{qrColor}</span>
                </div>
              </div>

              <div>
                <span className="text-xs text-slate-400 block mb-1.5">Orqa fon rangi:</span>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={bgColor}
                    onChange={(e) => setBgColor(e.target.value)}
                    className="w-9 h-9 rounded-xl bg-transparent border-0 cursor-pointer"
                  />
                  <span className="text-xs font-mono text-slate-300 uppercase">{bgColor}</span>
                </div>
              </div>
            </div>

            {/* Center Logo */}
            <div className="pt-2 border-t border-slate-800">
              <span className="text-xs text-slate-400 block mb-2">Markaziy ikona (Logo):</span>
              <div className="flex flex-wrap gap-2">
                {[
                  { id: 'none', label: 'Yo\'q' },
                  { id: 'telegram', label: '✈️ Telegram' },
                  { id: 'instagram', label: '📸 Instagram' },
                  { id: 'wifi', label: '📶 Wi-Fi' },
                  { id: 'web', label: '🌐 Veb' },
                  { id: 'star', label: '⭐ Yulduz' },
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setCenterLogo(item.id as any)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-colors ${
                      centerLogo === item.id
                        ? 'bg-emerald-600/20 border-emerald-500 text-emerald-300'
                        : 'bg-slate-800/40 border-slate-700/60 text-slate-400'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Size & Error correction */}
            <div className="grid grid-cols-2 gap-4 pt-2 border-t border-slate-800">
              <div>
                <span className="text-xs text-slate-400 block mb-1.5">Yuklab olish o'lchami:</span>
                <select
                  value={size}
                  onChange={(e) => setSize(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white"
                >
                  <option value={256}>256 x 256 px</option>
                  <option value={512}>512 x 512 px (Standart)</option>
                  <option value={1024}>1024 x 1024 px (HD)</option>
                </select>
              </div>

              <div>
                <span className="text-xs text-slate-400 block mb-1.5">Xatolikni tuzatish:</span>
                <select
                  value={errorCorrection}
                  onChange={(e) => setErrorCorrection(e.target.value as any)}
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white"
                >
                  <option value="L">L - Past (7%)</option>
                  <option value="M">M - O'rta (15%)</option>
                  <option value="Q">Q - Yuqori (25%)</option>
                  <option value="H">H - Eng yuqori (30%)</option>
                </select>
              </div>
            </div>

          </div>

        </div>

        {/* Right Live Preview & Download Buttons */}
        <div className="lg:col-span-5 flex flex-col items-center">
          <div className="sticky top-24 w-full flex flex-col items-center">
            
            {/* Live Canvas Box */}
            <div className="relative p-6 rounded-3xl bg-slate-900 border border-slate-800 shadow-2xl flex flex-col items-center justify-center">
              <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-400 mb-4">
                Jonli oldindan ko'rish
              </span>

              <div className="p-4 rounded-2xl bg-white shadow-md">
                <canvas ref={canvasRef} className="rounded-lg shadow-sm" />
              </div>

              <p className="text-[11px] text-slate-400 text-center mt-4 max-w-xs">
                Kamerangiz orqali skanerlab ko'rishingiz mumkin. Barcha smartfonlar bilan 100% mos keladi.
              </p>
            </div>

            {/* Action Buttons */}
            <div className="w-full space-y-3 mt-6 max-w-sm">
              <button
                onClick={handleDownloadPNG}
                className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white font-bold text-sm shadow-xl shadow-emerald-600/25 flex items-center justify-center gap-2 transition-all active:scale-[0.98]"
              >
                <Download className="w-4 h-4" />
                <span>PNG yuklab olish ({size}x{size})</span>
              </button>

              <button
                onClick={handleDownloadSVG}
                className="w-full py-3 px-4 rounded-2xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 text-xs sm:text-sm font-semibold flex items-center justify-center gap-2 transition-colors"
              >
                <Download className="w-4 h-4 text-emerald-400" />
                <span>SVG (Vektor) yuklab olish</span>
              </button>
            </div>

          </div>
        </div>

      </div>

    </div>
  );
};
