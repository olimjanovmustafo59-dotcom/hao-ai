import React, { useState, useRef } from 'react';
import { 
  Upload, 
  Wrench, 
  AlertTriangle, 
  CheckSquare, 
  Square, 
  RefreshCw, 
  Sparkles, 
  FileText, 
  ChevronRight, 
  ShieldAlert 
} from 'lucide-react';
import { aiService } from '../../services/aiService';
import { historyService } from '../../services/historyService';
import { SAMPLE_IMAGES, SAMPLE_REPAIR_PROBLEMS } from '../../services/sampleMedia';
import { RepairResult } from '../../types';

interface RepairAssistantToolProps {
  onBack: () => void;
}

export const RepairAssistantTool: React.FC<RepairAssistantToolProps> = ({ onBack }) => {
  const [imageSrc, setImageSrc] = useState<string | null>(null);
  const [problemText, setProblemText] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [result, setResult] = useState<RepairResult | null>(null);
  const [checkedSteps, setCheckedSteps] = useState<Record<number, boolean>>({});
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      setImageSrc(event.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleSelectQuickProblem = (sample: { device: string; problem: string }) => {
    setProblemText(`${sample.device}: ${sample.problem}`);
    if (sample.device.includes('Kir yuvish')) {
      setImageSrc(SAMPLE_IMAGES.washingMachine);
    }
  };

  const handleAnalyze = async () => {
    if (!problemText && !imageSrc) {
      alert("Iltimos, muammoni yozing yoki qurilma rasmini yuklang.");
      return;
    }

    setIsProcessing(true);
    setCheckedSteps({});

    try {
      const res = await aiService.repairAssistant(imageSrc || undefined, problemText);
      setResult(res);

      historyService.addHistory({
        toolId: 'repair',
        title: `${res.identifiedDevice || 'Qurilma'} ta'miri`,
        previewText: res.problemSummary,
        thumbnailUrl: imageSrc || undefined,
        data: res,
      });
    } catch (err) {
      console.error('Repair analysis error:', err);
    } finally {
      setIsProcessing(false);
    }
  };

  const toggleStep = (stepNum: number) => {
    setCheckedSteps(prev => ({
      ...prev,
      [stepNum]: !prev[stepNum],
    }));
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      
      {/* Header */}
      <div className="flex items-center justify-between pb-6 mb-6 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 hover:bg-slate-800 text-slate-300 text-sm font-medium transition-colors"
          >
            ← Orqaga
          </button>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-2xl">🛠️</span>
              <h1 className="text-xl sm:text-2xl font-bold text-white">Qanday ta'mirlash? — AI Repair Assistant</h1>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                AI Usta
              </span>
            </div>
            <p className="text-xs sm:text-sm text-slate-400">
              Telefon, kir yuvish mashinasi, muzlatgich, velosiped va boshqa texnikalardagi nosozliklarni aniqlang.
            </p>
          </div>
        </div>

        {result && (
          <button
            onClick={() => {
              setResult(null);
              setImageSrc(null);
              setProblemText('');
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs text-slate-300 transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Yangi so'rov</span>
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Column: Input and Upload */}
        <div className="lg:col-span-5 space-y-5">
          
          {/* Problem description input */}
          <div className="p-5 rounded-3xl bg-slate-900/80 border border-slate-800 shadow-xl space-y-4">
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-amber-400 block mb-2">
                1. Muammoni tasvirlang:
              </label>
              <textarea
                rows={3}
                value={problemText}
                onChange={(e) => setProblemText(e.target.value)}
                placeholder="Masalan: Kir yuvish mashinasidan suvi chiqmayapti, tsikl to'xtab qolmoqda..."
                className="w-full p-3.5 text-xs sm:text-sm bg-slate-800/80 border border-slate-700 rounded-2xl text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-amber-500/50"
              />
            </div>

            {/* Quick Suggestions */}
            <div>
              <span className="text-[11px] font-semibold text-slate-400 block mb-2">
                Tezkor namunalar:
              </span>
              <div className="flex flex-wrap gap-1.5">
                {SAMPLE_REPAIR_PROBLEMS.map((s, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleSelectQuickProblem(s)}
                    className="text-[11px] px-2.5 py-1 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700/60 transition-colors text-left flex items-center gap-1"
                  >
                    <span>{s.icon}</span>
                    <span>{s.device}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Photo upload */}
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-slate-300 block mb-2">
                2. Qurilma rasmi (ixtiyoriy, lekin tavsiya etiladi):
              </label>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handleFileUpload}
              />

              {imageSrc ? (
                <div className="relative rounded-2xl overflow-hidden border border-slate-700 bg-black/40 p-2">
                  <img
                    src={imageSrc}
                    alt="Yuklangan qurilma"
                    className="w-full h-40 object-contain rounded-xl"
                  />
                  <button
                    onClick={() => setImageSrc(null)}
                    className="absolute top-3 right-3 px-2 py-1 rounded-lg bg-black/70 hover:bg-black text-[11px] text-red-400"
                  >
                    O'chirish
                  </button>
                </div>
              ) : (
                <div
                  onClick={() => fileInputRef.current?.click()}
                  className="p-6 border-2 border-dashed border-slate-700 hover:border-amber-500 rounded-2xl bg-slate-800/40 text-center cursor-pointer transition-colors"
                >
                  <Upload className="w-6 h-6 mx-auto mb-2 text-slate-400" />
                  <p className="text-xs font-semibold text-slate-300">
                    Qurilma yoki nosoz joy rasmini yuklang
                  </p>
                  <p className="text-[10px] text-slate-500 mt-0.5">
                    Telefon, kompyuter, kir yuvish mashinasi, avtomobil va h.k.
                  </p>
                </div>
              )}
            </div>

            <button
              onClick={handleAnalyze}
              disabled={isProcessing || (!problemText && !imageSrc)}
              className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-amber-500 via-orange-500 to-red-500 hover:from-amber-400 hover:to-red-400 disabled:opacity-50 text-white font-bold text-sm shadow-xl shadow-amber-600/25 flex items-center justify-center gap-2 transition-all active:scale-[0.98]"
            >
              {isProcessing ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>AI tahlil qilmoqda...</span>
                </>
              ) : (
                <>
                  <Wrench className="w-4 h-4" />
                  <span>Ta'mirlash bo'yicha maslahat olish</span>
                </>
              )}
            </button>
          </div>

        </div>

        {/* Right Column: Troubleshooting Guide Result */}
        <div className="lg:col-span-7">
          {!result && !isProcessing && (
            <div className="p-12 rounded-3xl bg-slate-900/40 border border-slate-800 text-center text-slate-400">
              <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-amber-500/10 flex items-center justify-center text-3xl">
                🛠️
              </div>
              <h3 className="text-base font-bold text-white mb-2">
                Texnik ta'mirlash bo'yicha sun'iy intellekt
              </h3>
              <p className="text-xs sm:text-sm text-slate-400 max-w-md mx-auto leading-relaxed">
                Chap tomonda muammoingizni yozing yoki qurilma rasmini biriktiring. AI sizga qadamma-qadam tekshirish ketma-ketligini taqdim etadi.
              </p>
            </div>
          )}

          {isProcessing && (
            <div className="p-8 rounded-3xl bg-slate-900/60 border border-slate-800 animate-pulse space-y-4">
              <div className="h-6 bg-slate-800 rounded-xl w-2/3" />
              <div className="h-4 bg-slate-800 rounded-lg w-full" />
              <div className="h-20 bg-slate-800 rounded-2xl w-full" />
              <div className="h-32 bg-slate-800 rounded-2xl w-full" />
            </div>
          )}

          {result && !isProcessing && (
            <div className="space-y-5 animate-in fade-in slide-in-from-bottom-2 duration-300">
              
              {/* Device and Problem Header Card */}
              <div className="p-6 rounded-3xl bg-slate-900/90 border border-amber-500/30 shadow-xl">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[11px] font-extrabold uppercase tracking-wider text-amber-400">
                    Qurilma tahlili
                  </span>
                  <span className="text-xs px-2.5 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                    {result.identifiedDevice}
                  </span>
                </div>
                <h3 className="text-xl sm:text-2xl font-bold text-white mb-2">
                  {result.problemSummary}
                </h3>
              </div>

              {/* Safety Warning (Muhim) */}
              {result.warning && (
                <div className="p-5 rounded-2xl bg-red-500/10 border-2 border-red-500/40 flex items-start gap-3.5">
                  <ShieldAlert className="w-6 h-6 text-red-400 flex-shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-xs font-bold uppercase tracking-wider text-red-400 mb-1">
                      Muhim xavfsizlik ogohlantirishi!
                    </h4>
                    <p className="text-xs sm:text-sm text-red-200 leading-relaxed font-medium">
                      {result.warning}
                    </p>
                  </div>
                </div>
              )}

              {/* Muammo / Possible causes */}
              <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 mb-3 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-400" />
                  <span>Ehtimoliy sabablar (Muammo ildizi)</span>
                </h4>
                <ul className="space-y-2">
                  {result.possibleCauses.map((cause, i) => (
                    <li key={i} className="flex items-start gap-2.5 text-xs sm:text-sm text-slate-300">
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-400 mt-2 flex-shrink-0" />
                      <span>{cause}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Tekshirib ko'ring / Step by Step Troubleshooting */}
              <div className="p-6 rounded-3xl bg-slate-900/80 border border-slate-800 shadow-xl">
                <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-400 mb-4 flex items-center gap-2">
                  <CheckSquare className="w-4 h-4" />
                  <span>Tekshirib ko‘ring (Ketma-ket amallar)</span>
                </h4>

                <div className="space-y-3">
                  {result.troubleshootingSteps.map((step) => {
                    const isDone = Boolean(checkedSteps[step.step]);

                    return (
                      <div
                        key={step.step}
                        onClick={() => toggleStep(step.step)}
                        className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-start gap-3.5 ${
                          isDone
                            ? 'bg-emerald-950/20 border-emerald-500/40 opacity-70'
                            : 'bg-slate-800/40 border-slate-700/60 hover:border-slate-600'
                        }`}
                      >
                        <div className="mt-0.5 flex-shrink-0 text-emerald-400">
                          {isDone ? (
                            <CheckSquare className="w-5 h-5 fill-emerald-500/20" />
                          ) : (
                            <Square className="w-5 h-5 text-slate-500" />
                          )}
                        </div>

                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-slate-800 text-slate-300">
                              {step.step}-qadam
                            </span>
                            <h5 className={`text-xs sm:text-sm font-bold ${isDone ? 'line-through text-slate-400' : 'text-white'}`}>
                              {step.title}
                            </h5>
                          </div>
                          <p className={`text-xs leading-relaxed ${isDone ? 'text-slate-500' : 'text-slate-300'}`}>
                            {step.instruction}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Kerak bo'lishi mumkin (Tools & Parts) */}
              {result.toolsNeeded && result.toolsNeeded.length > 0 && (
                <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-purple-400 mb-3 flex items-center gap-2">
                    <Wrench className="w-4 h-4" />
                    <span>Kerak bo‘lishi mumkin bo'lgan asboblar:</span>
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {result.toolsNeeded.map((tool, idx) => (
                      <span
                        key={idx}
                        className="px-3 py-1.5 rounded-xl bg-purple-500/10 text-purple-300 text-xs border border-purple-500/20 font-medium"
                      >
                        🔧 {tool}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Muammoni qayta tekshirish Button */}
              <button
                onClick={handleAnalyze}
                className="w-full py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs sm:text-sm font-semibold flex items-center justify-center gap-2 transition-colors"
              >
                <RefreshCw className="w-4 h-4" />
                <span>Muammoni qayta tekshirish</span>
              </button>

            </div>
          )}
        </div>

      </div>

    </div>
  );
};
