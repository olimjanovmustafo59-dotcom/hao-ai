import React, { useState, useRef, useEffect } from 'react';
import { 
  Upload, 
  Film, 
  Download, 
  Play, 
  Pause, 
  Plus, 
  Trash2, 
  Edit3, 
  Sliders, 
  Type, 
  Languages, 
  Sparkles, 
  Check, 
  RefreshCw, 
  Clock 
} from 'lucide-react';
import { aiService } from '../../services/aiService';
import { historyService } from '../../services/historyService';
import { SubtitleCue, SubtitleResult } from '../../types';

interface SubtitleToolProps {
  onBack: () => void;
}

export const SubtitleTool: React.FC<SubtitleToolProps> = ({ onBack }) => {
  const [videoSrc, setVideoSrc] = useState<string | null>(null);
  const [videoName, setVideoName] = useState<string>('videorolik.mp4');
  const [selectedLang, setSelectedLang] = useState<'uz' | 'ru' | 'en'>('uz');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [progress, setProgress] = useState<number>(0);
  const [result, setResult] = useState<SubtitleResult | null>(null);
  
  // Video Player state
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(25);

  // Subtitle Styling Controls
  const [fontFamily, setFontFamily] = useState<string>('sans-serif');
  const [fontSize, setFontSize] = useState<number>(20);
  const [textColor, setTextColor] = useState<string>('#ffffff');
  const [bgColor, setBgColor] = useState<string>('rgba(0, 0, 0, 0.7)');
  const [position, setPosition] = useState<'bottom' | 'center' | 'top'>('bottom');

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setVideoName(file.name);
    const url = URL.createObjectURL(file);
    setVideoSrc(url);
    runTranscription(file.name);
  };

  const handleUseSample = () => {
    setVideoName("namuna_prezentatsiya.mp4");
    // Synthetic video or canvas preview
    setVideoSrc("https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4");
    runTranscription("namuna_prezentatsiya.mp4");
  };

  const runTranscription = async (name: string) => {
    setIsProcessing(true);
    setProgress(15);

    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 90) {
          clearInterval(interval);
          return 90;
        }
        return prev + 15;
      });
    }, 300);

    try {
      const res = await aiService.generateSubtitles({
        videoName: name,
        language: selectedLang,
        duration: 25,
      });

      clearInterval(interval);
      setProgress(100);
      setResult(res);

      historyService.addHistory({
        toolId: 'subtitles',
        title: `Subtitr: ${name}`,
        previewText: `${res.subtitles.length} ta subtitr qatori (${res.detectedLanguage})`,
        data: res,
      });
    } catch (e) {
      console.error('Subtitle generation error:', e);
    } finally {
      setIsProcessing(false);
    }
  };

  // Convert time string "00:00:01.500" to seconds
  const parseSeconds = (timeStr: string): number => {
    const parts = timeStr.split(':');
    if (parts.length < 3) return 0;
    const h = parseFloat(parts[0]);
    const m = parseFloat(parts[1]);
    const s = parseFloat(parts[2]);
    return h * 3600 + m * 60 + s;
  };

  // Format seconds to "00:00:01.500"
  const formatSeconds = (sec: number): string => {
    const hrs = Math.floor(sec / 3600);
    const mins = Math.floor((sec % 3600) / 60);
    const secs = sec % 60;
    return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toFixed(3).padStart(6, '0')}`;
  };

  // Active subtitle text currently visible at currentTime
  const currentSubtitle = result?.subtitles.find((sub) => {
    const startSec = parseSeconds(sub.start);
    const endSec = parseSeconds(sub.end);
    return currentTime >= startSec && currentTime <= endSec;
  });

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      setCurrentTime(videoRef.current.currentTime);
    }
  };

  const togglePlay = () => {
    if (!videoRef.current) return;
    if (isPlaying) {
      videoRef.current.pause();
      setIsPlaying(false);
    } else {
      videoRef.current.play();
      setIsPlaying(true);
    }
  };

  const handleSeek = (timeSec: number) => {
    if (videoRef.current) {
      videoRef.current.currentTime = timeSec;
      setCurrentTime(timeSec);
    }
  };

  // Cue Editing
  const updateCueText = (id: number, newText: string) => {
    if (!result) return;
    const updated = result.subtitles.map(c => c.id === id ? { ...c, text: newText } : c);
    setResult({ ...result, subtitles: updated });
  };

  const updateCueTiming = (id: number, field: 'start' | 'end', val: string) => {
    if (!result) return;
    const updated = result.subtitles.map(c => c.id === id ? { ...c, [field]: val } : c);
    setResult({ ...result, subtitles: updated });
  };

  const deleteCue = (id: number) => {
    if (!result) return;
    const updated = result.subtitles.filter(c => c.id !== id);
    setResult({ ...result, subtitles: updated });
  };

  const addCue = () => {
    if (!result) return;
    const newId = Date.now();
    const lastCue = result.subtitles[result.subtitles.length - 1];
    const startSec = lastCue ? parseSeconds(lastCue.end) + 0.5 : currentTime;
    const endSec = startSec + 3;

    const newCue: SubtitleCue = {
      id: newId,
      start: formatSeconds(startSec),
      end: formatSeconds(endSec),
      text: "Yangi subtitr matni...",
    };

    setResult({ ...result, subtitles: [...result.subtitles, newCue] });
  };

  // Export SRT
  const handleDownloadSRT = () => {
    if (!result) return;
    let srtContent = '';
    result.subtitles.forEach((cue, index) => {
      // SRT format requires comma instead of period for milliseconds: 00:00:01,500
      const startSrt = cue.start.replace('.', ',');
      const endSrt = cue.end.replace('.', ',');
      srtContent += `${index + 1}\n${startSrt} --> ${endSrt}\n${cue.text}\n\n`;
    });

    const blob = new Blob([srtContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${videoName.replace(/\.[^/.]+$/, '')}_subtitr.srt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Export Video with Subtitles info / Download
  const handleDownloadVideoWithSubtitles = () => {
    if (!result) return;
    // Download SRT alongside or notification
    handleDownloadSRT();
    alert("Subtitr SRT fayli yuklab olindi! Ushbu faylni videongiz bilan birga Telegram, YouTube yoki media pleyerda to'g'ridan-to'g'ri ishlatishingiz mumkin.");
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      
      {/* Header */}
      <div className="flex items-center justify-between pb-6 mb-6 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 hover:bg-slate-800 text-slate-300 text-sm font-medium transition-colors"
          >
            ← Orqaga
          </button>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-2xl">🎬</span>
              <h1 className="text-xl sm:text-2xl font-bold text-white">Video → Subtitle</h1>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/20 text-rose-300 border border-rose-500/30">
                Speech to Subtitle
              </span>
            </div>
            <p className="text-xs sm:text-sm text-slate-400">
              Videodan nutqni ajratib oling, vaqt shkalasida tahrirlang va tayyor SRT yuklab oling.
            </p>
          </div>
        </div>

        {result && (
          <button
            onClick={() => {
              setResult(null);
              setVideoSrc(null);
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs text-slate-300 transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Yangi video</span>
          </button>
        )}
      </div>

      {!videoSrc ? (
        /* Upload Area */
        <div className="max-w-2xl mx-auto py-10">
          <div
            onClick={() => fileInputRef.current?.click()}
            className="group relative flex flex-col items-center justify-center p-12 border-2 border-dashed border-slate-700 hover:border-rose-500 rounded-3xl bg-slate-900/50 hover:bg-slate-900/80 transition-all duration-300 cursor-pointer text-center"
          >
            <input
              ref={fileInputRef}
              type="file"
              accept="video/*"
              className="hidden"
              onChange={handleFileUpload}
            />

            <div className="w-20 h-20 rounded-3xl bg-rose-500/10 border border-rose-500/20 flex items-center justify-center text-4xl mb-6 group-hover:scale-110 transition-transform">
              🎬
            </div>

            <h3 className="text-xl font-bold text-white mb-2">
              Videoni yuklang (MP4, WEBM, MOV)
            </h3>
            <p className="text-sm text-slate-400 max-w-md mb-6">
              AI videodagi nutqni taniydi, vaqt kodlari (timecode) bilan subtitr yaratadi va tahrirlash imkonini beradi.
            </p>

            {/* Language Selector before upload */}
            <div className="flex items-center gap-2 mb-6" onClick={(e) => e.stopPropagation()}>
              <span className="text-xs text-slate-400">Til:</span>
              {(['uz', 'ru', 'en'] as const).map((lang) => (
                <button
                  key={lang}
                  type="button"
                  onClick={() => setSelectedLang(lang)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold border ${
                    selectedLang === lang
                      ? 'bg-rose-600 border-rose-500 text-white'
                      : 'bg-slate-800 border-slate-700 text-slate-400'
                  }`}
                >
                  {lang === 'uz' ? "O'zbekcha 🇺🇿" : lang === 'ru' ? "Русский 🇷🇺" : "English 🇬🇧"}
                </button>
              ))}
            </div>

            <div className="flex flex-wrap items-center justify-center gap-3">
              <button
                type="button"
                className="px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs sm:text-sm font-semibold shadow-lg shadow-rose-600/30 flex items-center gap-2"
              >
                <Upload className="w-4 h-4" />
                <span>Qurilmadan video tanlash</span>
              </button>

              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  handleUseSample();
                }}
                className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs sm:text-sm font-medium flex items-center gap-2"
              >
                <Sparkles className="w-4 h-4 text-rose-400" />
                <span>Namuna video bilan sinash</span>
              </button>
            </div>
          </div>
        </div>
      ) : (
        /* Video & Subtitle Workspace */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Column: Video Player with Live Subtitle Overlay */}
          <div className="lg:col-span-6 space-y-5">
            
            {/* Player Container */}
            <div className="relative aspect-video rounded-3xl overflow-hidden bg-black border border-slate-800 shadow-2xl flex items-center justify-center">
              <video
                ref={videoRef}
                src={videoSrc}
                className="w-full h-full object-contain"
                onTimeUpdate={handleTimeUpdate}
                onLoadedMetadata={(e) => setDuration(e.currentTarget.duration || 25)}
                onClick={togglePlay}
              />

              {/* Subtitle Overlay */}
              {currentSubtitle && (
                <div
                  className={`absolute left-4 right-4 pointer-events-none flex justify-center text-center transition-all ${
                    position === 'top'
                      ? 'top-6'
                      : position === 'center'
                      ? 'top-1/2 -translate-y-1/2'
                      : 'bottom-8'
                  }`}
                >
                  <span
                    className="px-3.5 py-1.5 rounded-xl max-w-[90%] font-semibold tracking-wide drop-shadow-lg"
                    style={{
                      fontFamily,
                      fontSize: `${fontSize}px`,
                      color: textColor,
                      backgroundColor: bgColor,
                    }}
                  >
                    {currentSubtitle.text}
                  </span>
                </div>
              )}

              {/* Processing Progress Overlay */}
              {isProcessing && (
                <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center">
                  <div className="w-14 h-14 rounded-full border-4 border-rose-500/20 border-t-rose-500 animate-spin mb-4" />
                  <h4 className="text-white font-bold text-base mb-1">
                    Nutq aniqlanmoqda ({progress}%)
                  </h4>
                  <p className="text-xs text-slate-400 max-w-xs mb-3">
                    Video ovozi ajratilib, timecode lar bo'yicha matnga o'girilmoqda...
                  </p>
                  <div className="w-48 h-2 bg-slate-800 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-rose-500 transition-all duration-300"
                      style={{ width: `${progress}%` }}
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Custom Video Playbar */}
            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex items-center gap-3">
              <button
                onClick={togglePlay}
                className="p-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white transition-colors"
              >
                {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              </button>

              <div className="flex-1 flex items-center gap-2">
                <span className="text-xs font-mono text-slate-400">
                  {formatSeconds(currentTime).substring(3, 8)}
                </span>
                <input
                  type="range"
                  min="0"
                  max={duration || 25}
                  step="0.1"
                  value={currentTime}
                  onChange={(e) => handleSeek(Number(e.target.value))}
                  className="flex-1 accent-rose-500"
                />
                <span className="text-xs font-mono text-slate-400">
                  {formatSeconds(duration).substring(3, 8)}
                </span>
              </div>
            </div>

            {/* Subtitle Style Customization */}
            <div className="p-5 rounded-3xl bg-slate-900/80 border border-slate-800 shadow-xl space-y-4">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold uppercase tracking-wider text-rose-400">
                  Subtitr uslubi va sozlamalari
                </label>
              </div>

              <div className="grid grid-cols-2 gap-4">
                {/* Font Size */}
                <div>
                  <span className="text-xs text-slate-400 block mb-1">O'lcham: {fontSize}px</span>
                  <input
                    type="range"
                    min="14"
                    max="36"
                    value={fontSize}
                    onChange={(e) => setFontSize(Number(e.target.value))}
                    className="w-full accent-rose-500"
                  />
                </div>

                {/* Vertical Position */}
                <div>
                  <span className="text-xs text-slate-400 block mb-1">Joylashuv:</span>
                  <div className="flex gap-1">
                    {(['top', 'center', 'bottom'] as const).map((pos) => (
                      <button
                        key={pos}
                        onClick={() => setPosition(pos)}
                        className={`flex-1 py-1 rounded-lg text-xs font-medium border ${
                          position === pos
                            ? 'bg-rose-600 border-rose-500 text-white'
                            : 'bg-slate-800 border-slate-700 text-slate-400'
                        }`}
                      >
                        {pos === 'bottom' ? 'Pastda' : pos === 'center' ? 'O\'rtada' : 'Yuqorida'}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 pt-2 border-t border-slate-800">
                {/* Text Color */}
                <div>
                  <span className="text-xs text-slate-400 block mb-1.5">Matn rangi:</span>
                  <div className="flex items-center gap-1.5">
                    {['#ffffff', '#fde047', '#38bdf8', '#4ade80', '#f43f5e'].map((col) => (
                      <button
                        key={col}
                        onClick={() => setTextColor(col)}
                        className={`w-6 h-6 rounded-full border ${textColor === col ? 'border-rose-400 scale-110' : 'border-transparent'}`}
                        style={{ backgroundColor: col }}
                      />
                    ))}
                  </div>
                </div>

                {/* Background Box */}
                <div>
                  <span className="text-xs text-slate-400 block mb-1.5">Orqa fon:</span>
                  <div className="flex items-center gap-1.5">
                    {[
                      { id: 'rgba(0, 0, 0, 0.75)', label: 'Qora' },
                      { id: 'rgba(15, 23, 42, 0.85)', label: 'To\'q' },
                      { id: 'rgba(225, 29, 72, 0.8)', label: 'Qizil' },
                      { id: 'transparent', label: 'Yo\'q' },
                    ].map((bg) => (
                      <button
                        key={bg.id}
                        onClick={() => setBgColor(bg.id)}
                        className={`px-2 py-0.5 rounded text-[10px] font-semibold border ${
                          bgColor === bg.id ? 'border-rose-400 text-rose-300' : 'border-slate-700 text-slate-400'
                        }`}
                      >
                        {bg.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Export Buttons */}
            <div className="space-y-2">
              <button
                onClick={handleDownloadSRT}
                className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-rose-600 via-purple-600 to-indigo-600 hover:from-rose-500 hover:to-indigo-500 text-white font-bold text-sm shadow-xl shadow-rose-600/25 flex items-center justify-center gap-2 transition-all active:scale-[0.98]"
              >
                <Download className="w-4 h-4" />
                <span>SRT faylni yuklab olish (.srt)</span>
              </button>

              <button
                onClick={handleDownloadVideoWithSubtitles}
                className="w-full py-2.5 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 text-xs font-semibold flex items-center justify-center gap-2 transition-colors"
              >
                <Film className="w-4 h-4 text-rose-400" />
                <span>Videoga o'rnatilgan holda saqlash</span>
              </button>
            </div>

          </div>

          {/* Right Column: Interactive Subtitle Timeline Table */}
          <div className="lg:col-span-6 space-y-4">
            
            <div className="p-6 rounded-3xl bg-slate-900/80 border border-slate-800 shadow-xl">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-base font-bold text-white flex items-center gap-2">
                    <Clock className="w-4 h-4 text-rose-400" />
                    <span>Subtitrlar xronologiyasi (Timeline)</span>
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Har bir qator matnini va vaqtini to'g'ridan-to'g'ri o'zgartirishingiz mumkin.
                  </p>
                </div>

                <button
                  onClick={addCue}
                  className="px-3 py-1.5 rounded-xl bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 border border-rose-500/30 text-xs font-semibold flex items-center gap-1.5 transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Qator qo'shish</span>
                </button>
              </div>

              {/* Subtitles list */}
              <div className="space-y-3 max-h-[520px] overflow-y-auto pr-1">
                {result?.subtitles.map((cue, idx) => {
                  const isActive = currentSubtitle?.id === cue.id;
                  const startSec = parseSeconds(cue.start);

                  return (
                    <div
                      key={cue.id}
                      className={`p-3.5 rounded-2xl border transition-all ${
                        isActive
                          ? 'bg-rose-950/20 border-rose-500/60 ring-1 ring-rose-500/40 shadow-lg shadow-rose-950/30'
                          : 'bg-slate-800/40 border-slate-700/60 hover:border-slate-600'
                      }`}
                    >
                      {/* Top time controls */}
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => handleSeek(startSec)}
                            className="text-[11px] px-2 py-0.5 rounded-md bg-slate-800 hover:bg-rose-600 text-slate-300 hover:text-white font-mono flex items-center gap-1 transition-colors"
                            title="Shu daqiqaga o'tish"
                          >
                            <Play className="w-2.5 h-2.5" />
                            <span>{cue.start.substring(3, 8)} - {cue.end.substring(3, 8)}</span>
                          </button>
                          <span className="text-[10px] text-slate-500">#{idx + 1}</span>
                        </div>

                        <button
                          onClick={() => deleteCue(cue.id)}
                          className="text-slate-500 hover:text-red-400 p-1 rounded transition-colors"
                          title="Qatorni o'chirish"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      {/* Text editor */}
                      <textarea
                        rows={2}
                        value={cue.text}
                        onChange={(e) => updateCueText(cue.id, e.target.value)}
                        className="w-full p-2.5 text-xs sm:text-sm bg-slate-900 border border-slate-700/80 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-rose-500"
                      />
                    </div>
                  );
                })}
              </div>

            </div>

          </div>

        </div>
      )}

    </div>
  );
};
