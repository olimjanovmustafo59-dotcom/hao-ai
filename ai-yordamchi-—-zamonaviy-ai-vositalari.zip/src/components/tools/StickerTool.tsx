import React, { useState, useRef, useEffect } from 'react';
import { 
  Upload, 
  Sparkles, 
  Download, 
  RefreshCw, 
  RotateCw, 
  ZoomIn, 
  Type, 
  Smile, 
  Sliders, 
  Trash2, 
  Undo2, 
  Redo2, 
  Check, 
  Camera,
  Layers
} from 'lucide-react';
import { aiService } from '../../services/aiService';
import { historyService } from '../../services/historyService';
import { SAMPLE_IMAGES } from '../../services/sampleMedia';
import { StickerStyle, StickerOverlayText, StickerOverlayEmoji } from '../../types';

interface StickerToolProps {
  onBack: () => void;
}

interface CanvasState {
  imageSrc: string | null;
  outlineWidth: number;
  outlineColor: string;
  style: StickerStyle;
  scale: number;
  rotation: number;
  texts: StickerOverlayText[];
  emojis: StickerOverlayEmoji[];
}

export const StickerTool: React.FC<StickerToolProps> = ({ onBack }) => {
  const [imageSrc, setImageSrc] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [outlineWidth, setOutlineWidth] = useState<number>(12);
  const [outlineColor, setOutlineColor] = useState<string>('#ffffff');
  const [selectedStyle, setSelectedStyle] = useState<StickerStyle>('classic');
  const [scale, setScale] = useState<number>(1);
  const [rotation, setRotation] = useState<number>(0);
  const [removeBg, setRemoveBg] = useState<boolean>(true);

  // Overlays
  const [texts, setTexts] = useState<StickerOverlayText[]>([
    { id: '1', text: "Zo'r! 🔥", color: '#ffffff', strokeColor: '#000000', fontSize: 32, x: 256, y: 440, rotation: 0 }
  ]);
  const [newTextInput, setNewTextInput] = useState<string>('');
  const [emojis, setEmojis] = useState<StickerOverlayEmoji[]>([]);
  
  // Undo/Redo stack
  const [history, setHistory] = useState<CanvasState[]>([]);
  const [historyIndex, setHistoryIndex] = useState<number>(-1);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Initialize with sample image if none
  const handleLoadSample = () => {
    setImageSrc(SAMPLE_IMAGES.cuteCat);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert("Iltimos, faqat rasm faylini yuklang (PNG, JPG, WEBP).");
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      setImageSrc(event.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  // Render sticker on canvas
  const renderCanvas = async () => {
    if (!canvasRef.current || !imageSrc) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Telegram standard 512x512
    canvas.width = 512;
    canvas.height = 512;
    ctx.clearRect(0, 0, 512, 512);

    try {
      // Process main base image with outline and bg removal
      const processedDataUrl = await aiService.generateSticker(imageSrc, {
        outlineWidth,
        outlineColor,
        style: selectedStyle,
        removeBackground: removeBg,
      });

      const processedImg = new Image();
      processedImg.crossOrigin = 'anonymous';
      processedImg.onload = () => {
        ctx.clearRect(0, 0, 512, 512);
        
        ctx.save();
        ctx.translate(256, 256);
        ctx.rotate((rotation * Math.PI) / 180);
        ctx.scale(scale, scale);
        ctx.drawImage(processedImg, -256, -256, 512, 512);
        ctx.restore();

        // Draw emojis
        emojis.forEach((em) => {
          ctx.save();
          ctx.translate(em.x, em.y);
          ctx.rotate((em.rotation * Math.PI) / 180);
          ctx.font = `${em.size}px "Apple Color Emoji", "Segoe UI Emoji", "Noto Color Emoji", sans-serif`;
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText(em.emoji, 0, 0);
          ctx.restore();
        });

        // Draw texts with sticker-like stroke
        texts.forEach((txt) => {
          ctx.save();
          ctx.translate(txt.x, txt.y);
          ctx.rotate((txt.rotation * Math.PI) / 180);
          ctx.font = `900 ${txt.fontSize}px 'Plus Jakarta Sans', sans-serif`;
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';

          // Outer stroke for legibility
          ctx.lineWidth = 8;
          ctx.strokeStyle = txt.strokeColor || '#000000';
          ctx.lineJoin = 'round';
          ctx.strokeText(txt.text, 0, 0);

          // Fill
          ctx.fillStyle = txt.color || '#ffffff';
          ctx.fillText(txt.text, 0, 0);
          ctx.restore();
        });
      };
      processedImg.src = processedDataUrl;
    } catch (e) {
      console.error('Render sticker error:', e);
    }
  };

  useEffect(() => {
    if (imageSrc) {
      renderCanvas();
    }
  }, [imageSrc, outlineWidth, outlineColor, selectedStyle, scale, rotation, removeBg, texts, emojis]);

  const handleAddText = () => {
    if (!newTextInput.trim()) return;
    const newText: StickerOverlayText = {
      id: Date.now().toString(),
      text: newTextInput.trim(),
      color: '#ffffff',
      strokeColor: '#0f172a',
      fontSize: 34,
      x: 256,
      y: texts.length === 0 ? 440 : 80,
      rotation: 0,
    };
    setTexts([...texts, newText]);
    setNewTextInput('');
  };

  const handleAddEmoji = (emoji: string) => {
    const newEmoji: StickerOverlayEmoji = {
      id: Date.now().toString(),
      emoji,
      size: 54,
      x: 256 + (Math.random() * 80 - 40),
      y: 200 + (Math.random() * 80 - 40),
      rotation: Math.floor(Math.random() * 20 - 10),
    };
    setEmojis([...emojis, newEmoji]);
  };

  const handleDownload = () => {
    if (!canvasRef.current) return;
    const canvas = canvasRef.current;
    const dataUrl = canvas.toDataURL('image/png');

    const link = document.createElement('a');
    link.download = `sticker_ai_yordamchi_${Date.now()}.png`;
    link.href = dataUrl;
    link.click();

    // Save to user history
    historyService.addHistory({
      toolId: 'sticker',
      title: "Yangi Telegram Sticker",
      previewText: `Stil: ${selectedStyle}, Matnlar: ${texts.map(t => t.text).join(', ') || 'Yo\'q'}`,
      thumbnailUrl: dataUrl,
      data: {
        outlineWidth,
        outlineColor,
        selectedStyle,
      },
    });
  };

  const stylesList: { id: StickerStyle; label: string; desc: string }[] = [
    { id: 'classic', label: 'Klassik', desc: 'Aniq va toza oq kontur' },
    { id: 'funny', label: 'Kulgili', desc: 'Yorqin ranglar va yumor' },
    { id: 'cartoon', label: 'Multfilm', desc: 'To\'yingan va multfilmbop' },
    { id: 'emoji', label: 'Emoji', desc: 'Emotsiyalarga boy uslub' },
    { id: 'minimal', label: 'Minimal', desc: 'Yupqa kontur va soddalik' },
  ];

  const quickEmojis = ['🔥', '😂', '🚀', '❤️', '⚡', '😎', '💡', '👏', '🏆', '🇺🇿', '💪', '👍'];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      
      {/* Top Header */}
      <div className="flex items-center justify-between pb-6 mb-6 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 hover:bg-slate-800 text-slate-300 text-sm font-medium transition-colors"
          >
            ← Orqaga
          </button>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-2xl">📸</span>
              <h1 className="text-xl sm:text-2xl font-bold text-white">Rasm → Sticker</h1>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-purple-500/20 text-purple-300 border border-purple-500/30">
                Telegram 512x512
              </span>
            </div>
            <p className="text-xs sm:text-sm text-slate-400">
              Rasmdan fonni olib tashlang, oq kontur va matn qo'shib Telegram sticker yarating.
            </p>
          </div>
        </div>

        <button
          onClick={() => {
            setImageSrc(null);
            setTexts([]);
            setEmojis([]);
          }}
          className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs text-slate-300 transition-colors"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Yangi sticker</span>
        </button>
      </div>

      {!imageSrc ? (
        /* Upload Area */
        <div className="max-w-2xl mx-auto py-12">
          <div
            onClick={() => fileInputRef.current?.click()}
            className="group relative flex flex-col items-center justify-center p-12 border-2 border-dashed border-slate-700 hover:border-purple-500 rounded-3xl bg-slate-900/50 hover:bg-slate-900/80 transition-all duration-300 cursor-pointer text-center"
          >
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleFileUpload}
            />
            
            <div className="w-20 h-20 rounded-3xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-4xl mb-6 group-hover:scale-110 transition-transform">
              📸
            </div>

            <h3 className="text-xl font-bold text-white mb-2">
              Rasmni bu yerga tashlang yoki tanlang
            </h3>
            <p className="text-sm text-slate-400 max-w-md mb-6">
              AI avtomatik ravishda obyektni taniydi, orqa fonni o'chiradi va stiker uchun kontur tayyorlaydi.
            </p>

            <div className="flex flex-wrap items-center justify-center gap-3">
              <button
                type="button"
                className="px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs sm:text-sm font-semibold shadow-lg shadow-purple-600/30 flex items-center gap-2"
              >
                <Upload className="w-4 h-4" />
                <span>Qurilmadan yuklash</span>
              </button>

              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  handleLoadSample();
                }}
                className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs sm:text-sm font-medium flex items-center gap-2"
              >
                <Sparkles className="w-4 h-4 text-amber-400" />
                <span>Namuna rasm bilan sinash</span>
              </button>
            </div>
          </div>
        </div>
      ) : (
        /* Workspace Editor */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Canvas Preview Area */}
          <div className="lg:col-span-6 flex flex-col items-center">
            <div className="relative w-full max-w-[460px] aspect-square rounded-3xl p-4 bg-slate-900/90 border border-slate-800 shadow-2xl flex items-center justify-center overflow-hidden">
              
              {/* Checkerboard Pattern for Transparency */}
              <div 
                className="absolute inset-4 rounded-2xl opacity-20 pointer-events-none"
                style={{
                  backgroundImage: `radial-gradient(#64748b 1px, transparent 1px)`,
                  backgroundSize: '16px 16px'
                }}
              />

              <canvas
                ref={canvasRef}
                className="relative z-10 w-full h-full object-contain filter drop-shadow-xl"
              />
            </div>

            {/* Quick action buttons below canvas */}
            <div className="flex items-center gap-2 mt-4 w-full max-w-[460px]">
              <button
                onClick={handleDownload}
                className="flex-1 py-3 px-4 rounded-2xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-semibold text-sm shadow-xl shadow-purple-600/25 flex items-center justify-center gap-2 transition-all active:scale-[0.98]"
              >
                <Download className="w-4 h-4" />
                <span>PNG yuklab olish (512x512)</span>
              </button>

              <button
                onClick={() => setImageSrc(null)}
                className="p-3 rounded-2xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-white transition-colors"
                title="Yangi sticker"
              >
                <RefreshCw className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Controls Settings Sidebar */}
          <div className="lg:col-span-6 space-y-6">
            
            {/* Style Selector */}
            <div className="p-5 rounded-2xl bg-slate-900/70 border border-slate-800">
              <label className="text-xs font-bold uppercase tracking-wider text-purple-400 mb-3 block">
                Sticker Uslubi (Style)
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {stylesList.map((st) => (
                  <button
                    key={st.id}
                    onClick={() => setSelectedStyle(st.id)}
                    className={`p-3 rounded-xl text-left border transition-all ${
                      selectedStyle === st.id
                        ? 'bg-purple-600/20 border-purple-500 text-white'
                        : 'bg-slate-800/40 border-slate-700/50 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <p className="text-xs font-bold">{st.label}</p>
                    <p className="text-[10px] text-slate-400 mt-0.5">{st.desc}</p>
                  </button>
                ))}
              </div>
            </div>

            {/* Background & Outline Controls */}
            <div className="p-5 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-4">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold uppercase tracking-wider text-slate-300">
                  Oq Kontur (Outline)
                </label>
                <span className="text-xs font-mono text-purple-400">{outlineWidth}px</span>
              </div>
              <input
                type="range"
                min="0"
                max="28"
                value={outlineWidth}
                onChange={(e) => setOutlineWidth(Number(e.target.value))}
                className="w-full accent-purple-500"
              />

              <div className="flex items-center justify-between pt-2">
                <span className="text-xs text-slate-400">Kontur rangi:</span>
                <div className="flex items-center gap-2">
                  {['#ffffff', '#000000', '#fbbf24', '#f43f5e', '#38bdf8'].map((col) => (
                    <button
                      key={col}
                      onClick={() => setOutlineColor(col)}
                      className={`w-6 h-6 rounded-full border-2 ${
                        outlineColor === col ? 'border-purple-400 scale-110' : 'border-transparent'
                      }`}
                      style={{ backgroundColor: col }}
                    />
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-slate-800">
                <span className="text-xs text-slate-300 font-medium">Orqa fonni avtomatik tozalash:</span>
                <button
                  onClick={() => setRemoveBg(!removeBg)}
                  className={`px-3 py-1 rounded-full text-xs font-semibold transition-colors ${
                    removeBg ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {removeBg ? 'Yoqilgan' : 'O\'chirilgan'}
                </button>
              </div>
            </div>

            {/* Text & Emoji Overlay */}
            <div className="p-5 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-4">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-300 block">
                Matn va Emojilar
              </label>

              {/* Text Input */}
              <div className="flex gap-2">
                <input
                  type="text"
                  value={newTextInput}
                  onChange={(e) => setNewTextInput(e.target.value)}
                  placeholder="Stickerga matn yozing (masalan: Zo'r! 🔥)..."
                  className="flex-1 px-3 py-2 text-xs bg-slate-800 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-purple-500"
                  onKeyDown={(e) => e.key === 'Enter' && handleAddText()}
                />
                <button
                  onClick={handleAddText}
                  className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-bold transition-colors"
                >
                  Qo'shish
                </button>
              </div>

              {/* Quick Emojis */}
              <div>
                <span className="text-[11px] text-slate-400 mb-1.5 block">Tezkor emojilar:</span>
                <div className="flex flex-wrap gap-1.5">
                  {quickEmojis.map((em) => (
                    <button
                      key={em}
                      onClick={() => handleAddEmoji(em)}
                      className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-base hover:scale-110 transition-transform"
                    >
                      {em}
                    </button>
                  ))}
                </div>
              </div>

              {/* Active Texts List */}
              {texts.length > 0 && (
                <div className="space-y-1.5 pt-2 border-t border-slate-800">
                  <span className="text-[11px] text-slate-400 block">Qo'shilgan matnlar:</span>
                  {texts.map((t) => (
                    <div key={t.id} className="flex items-center justify-between p-2 rounded-lg bg-slate-800/60 text-xs">
                      <span className="font-semibold text-white truncate">{t.text}</span>
                      <button
                        onClick={() => setTexts(texts.filter(item => item.id !== t.id))}
                        className="text-red-400 hover:text-red-300 p-1"
                        title="O'chirish"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Scale & Rotate */}
            <div className="p-5 rounded-2xl bg-slate-900/70 border border-slate-800 flex items-center justify-between gap-4">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setRotation((r) => (r - 90) % 360)}
                  className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs flex items-center gap-1"
                  title="90 gradus burish"
                >
                  <RotateCw className="w-3.5 h-3.5" />
                  <span>Burish</span>
                </button>

                <button
                  onClick={() => setScale((s) => Math.max(0.6, s - 0.1))}
                  className="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs"
                >
                  - Kichraytirish
                </button>

                <button
                  onClick={() => setScale((s) => Math.min(1.4, s + 0.1))}
                  className="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs"
                >
                  + Kattalashtirish
                </button>
              </div>

              <button
                onClick={() => {
                  setScale(1);
                  setRotation(0);
                }}
                className="text-xs text-slate-400 hover:text-white underline"
              >
                Tiklash
              </button>
            </div>

          </div>

        </div>
      )}

    </div>
  );
};
