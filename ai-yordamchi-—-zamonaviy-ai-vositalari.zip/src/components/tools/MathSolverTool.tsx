import React, { useState, useRef } from 'react';
import { 
  Upload, 
  Sparkles, 
  Calculator, 
  ArrowRight, 
  CheckCircle2, 
  HelpCircle, 
  RefreshCw, 
  Copy, 
  Check, 
  BookOpen, 
  ChevronDown, 
  ChevronUp 
} from 'lucide-react';
import { aiService } from '../../services/aiService';
import { historyService } from '../../services/historyService';
import { SAMPLE_IMAGES, SAMPLE_MATH_PROBLEMS } from '../../services/sampleMedia';
import { MathResult } from '../../types';

interface MathSolverToolProps {
  onBack: () => void;
}

export const MathSolverTool: React.FC<MathSolverToolProps> = ({ onBack }) => {
  const [inputMode, setInputMode] = useState<'text' | 'photo'>('text');
  const [problemText, setProblemText] = useState<string>('2x + 5 = 15');
  const [imageSrc, setImageSrc] = useState<string | null>(null);
  const [isSolving, setIsSolving] = useState<boolean>(false);
  const [result, setResult] = useState<MathResult | null>(null);
  const [showDeeperExplanation, setShowDeeperExplanation] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const virtualButtons = [
    { label: 'x', val: 'x' },
    { label: 'y', val: 'y' },
    { label: '+', val: ' + ' },
    { label: '−', val: ' - ' },
    { label: '×', val: ' × ' },
    { label: '÷', val: ' ÷ ' },
    { label: '=', val: ' = ' },
    { label: 'x²', val: '^2' },
    { label: '√', val: '√(' },
    { label: '( )', val: '()' },
    { label: '%', val: '%' },
    { label: 'π', val: 'π' },
    { label: '1/2', val: '½' },
    { label: '≤', val: ' ≤ ' },
    { label: '≥', val: ' ≥ ' },
  ];

  const handleAppendVirtual = (val: string) => {
    setProblemText((prev) => prev + val);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      setImageSrc(event.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleSolve = async () => {
    if (!problemText && !imageSrc) {
      alert("Iltimos, masala matnini kiriting yoki rasm yuklang.");
      return;
    }

    setIsSolving(true);
    setResult(null);
    setShowDeeperExplanation(false);

    try {
      const res = await aiService.solveMath({
        problemText: problemText || undefined,
        imageBase64: imageSrc || undefined,
      });

      setResult(res);

      historyService.addHistory({
        toolId: 'math',
        title: `Masala: ${res.recognizedExpression}`,
        previewText: `Javob: ${res.finalAnswer}`,
        thumbnailUrl: imageSrc || undefined,
        data: res,
      });
    } catch (e) {
      console.error('Math solve error:', e);
    } finally {
      setIsSolving(false);
    }
  };

  const handleCopySolution = () => {
    if (!result) return;
    const text = `Masala: ${result.recognizedExpression}\n` +
      result.steps.map(s => `${s.stepNumber}-qadam: ${s.expression} (${s.explanation})`).join('\n') +
      `\nJavob: ${result.finalAnswer}`;

    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      
      {/* Header */}
      <div className="flex items-center justify-between pb-6 mb-6 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 hover:bg-slate-800 text-slate-300 text-sm font-medium transition-colors"
          >
            ← Orqaga
          </button>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-2xl">🧮</span>
              <h1 className="text-xl sm:text-2xl font-bold text-white">Matematika Masala Yechuvchi</h1>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-purple-500/20 text-purple-300 border border-purple-500/30">
                Bosqichma-bosqich
              </span>
            </div>
            <p className="text-xs sm:text-sm text-slate-400">
              Tenglamalar, kasrlar, algebra, geometriya va amallarni qadamma-qadam tushunib yeching.
            </p>
          </div>
        </div>

        {result && (
          <button
            onClick={() => {
              setResult(null);
              setImageSrc(null);
              setProblemText('');
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs text-slate-300 transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Yangi masala</span>
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Column: Input selection */}
        <div className="lg:col-span-5 space-y-5">
          
          {/* Mode Switcher */}
          <div className="p-1 rounded-2xl bg-slate-900 border border-slate-800 flex">
            <button
              onClick={() => setInputMode('text')}
              className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition-all ${
                inputMode === 'text'
                  ? 'bg-purple-600 text-white shadow-lg shadow-purple-600/30'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Matn orqali yozish
            </button>
            <button
              onClick={() => setInputMode('photo')}
              className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition-all ${
                inputMode === 'photo'
                  ? 'bg-purple-600 text-white shadow-lg shadow-purple-600/30'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Rasm yuklash
            </button>
          </div>

          {/* Form Content */}
          <div className="p-5 rounded-3xl bg-slate-900/80 border border-slate-800 shadow-xl space-y-4">
            
            {inputMode === 'text' ? (
              <div>
                <label className="text-xs font-bold uppercase tracking-wider text-purple-400 block mb-2">
                  Matematik ifoda yoki masala:
                </label>
                <textarea
                  rows={3}
                  value={problemText}
                  onChange={(e) => setProblemText(e.target.value)}
                  placeholder="Masalan: 2x + 5 = 15 yoki 3x^2 - 12 = 0..."
                  className="w-full p-3 font-mono text-base bg-slate-800 border border-slate-700 rounded-2xl text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-purple-500/50"
                />

                {/* Virtual Math Keyboard Buttons */}
                <div className="mt-3">
                  <span className="text-[11px] text-slate-400 block mb-1.5 font-medium">
                    Matematik belgilar klaviaturasi:
                  </span>
                  <div className="grid grid-cols-5 gap-1.5">
                    {virtualButtons.map((btn, i) => (
                      <button
                        key={i}
                        type="button"
                        onClick={() => handleAppendVirtual(btn.val)}
                        className="py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-mono text-xs font-bold border border-slate-700/60 active:scale-95 transition-all"
                      >
                        {btn.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              <div>
                <label className="text-xs font-bold uppercase tracking-wider text-purple-400 block mb-2">
                  Masala daftari yoki kitob rasmi:
                </label>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleFileUpload}
                />

                {imageSrc ? (
                  <div className="relative rounded-2xl overflow-hidden border border-slate-700 bg-black/40 p-2">
                    <img
                      src={imageSrc}
                      alt="Masala rasmi"
                      className="w-full h-44 object-contain rounded-xl"
                    />
                    <button
                      onClick={() => setImageSrc(null)}
                      className="absolute top-3 right-3 px-2 py-1 rounded-lg bg-black/70 hover:bg-black text-[11px] text-red-400"
                    >
                      O'chirish
                    </button>
                  </div>
                ) : (
                  <div
                    onClick={() => fileInputRef.current?.click()}
                    className="p-8 border-2 border-dashed border-slate-700 hover:border-purple-500 rounded-2xl bg-slate-800/40 text-center cursor-pointer transition-colors"
                  >
                    <Upload className="w-8 h-8 mx-auto mb-2 text-slate-400" />
                    <p className="text-xs font-semibold text-slate-300">
                      Qo'lda yozilgan yoki kitobdagi masalani suratga oling
                    </p>
                    <p className="text-[10px] text-slate-500 mt-1">
                      AI ifodani matn ko'rinishida taniydi va tahlil qiladi
                    </p>
                  </div>
                )}
              </div>
            )}

            {/* Quick Sample Problems */}
            <div>
              <span className="text-[11px] text-slate-400 block mb-1.5 font-medium">
                Sinab ko'rish uchun namunalar:
              </span>
              <div className="flex flex-wrap gap-1.5">
                {SAMPLE_MATH_PROBLEMS.map((prob, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      setInputMode('text');
                      setProblemText(prob);
                    }}
                    className="text-[11px] px-2.5 py-1 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-mono border border-slate-700/60"
                  >
                    {prob}
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={handleSolve}
              disabled={isSolving || (!problemText && !imageSrc)}
              className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-violet-600 via-purple-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 disabled:opacity-50 text-white font-bold text-sm shadow-xl shadow-purple-600/25 flex items-center justify-center gap-2 transition-all active:scale-[0.98]"
            >
              {isSolving ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>AI masalani yechmoqda...</span>
                </>
              ) : (
                <>
                  <Calculator className="w-4 h-4" />
                  <span>Masalani qadamma-qadam yechish</span>
                </>
              )}
            </button>
          </div>

        </div>

        {/* Right Column: Step-by-Step Result Display */}
        <div className="lg:col-span-7">
          {!result && !isSolving && (
            <div className="p-12 rounded-3xl bg-slate-900/40 border border-slate-800 text-center text-slate-400">
              <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-purple-500/10 flex items-center justify-center text-3xl">
                🧮
              </div>
              <h3 className="text-base font-bold text-white mb-2">
                Qadamma-qadam tushuntiruvchi aqlli repetitor
              </h3>
              <p className="text-xs sm:text-sm text-slate-400 max-w-md mx-auto leading-relaxed">
                Chap tomonga algebraik tenglama yoki arifmetik amalni yozing. AI har bir qadamni tushuntirib, yakuniy natijani ko'rsatadi.
              </p>
            </div>
          )}

          {isSolving && (
            <div className="p-8 rounded-3xl bg-slate-900/60 border border-slate-800 animate-pulse space-y-4">
              <div className="h-6 bg-slate-800 rounded-xl w-1/3" />
              <div className="h-16 bg-slate-800 rounded-2xl w-full" />
              <div className="h-16 bg-slate-800 rounded-2xl w-full" />
              <div className="h-16 bg-slate-800 rounded-2xl w-full" />
            </div>
          )}

          {result && !isSolving && (
            <div className="space-y-4 animate-in fade-in slide-in-from-bottom-2 duration-300">
              
              {/* Problem Topic Header */}
              <div className="p-6 rounded-3xl bg-slate-900/90 border border-purple-500/30 shadow-xl flex items-center justify-between">
                <div>
                  <span className="text-[11px] font-extrabold uppercase tracking-wider text-purple-400 block mb-1">
                    {result.topic}
                  </span>
                  <h3 className="text-xl sm:text-2xl font-mono font-bold text-white">
                    {result.recognizedExpression}
                  </h3>
                </div>

                <button
                  onClick={handleCopySolution}
                  className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs text-slate-300 font-medium flex items-center gap-1.5 border border-slate-700 transition-colors"
                  title="Yechimdan nusxa olish"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Nusxalandi!' : 'Nusxa'}</span>
                </button>
              </div>

              {/* Step by Step Breakdown */}
              <div className="space-y-3">
                {result.steps.map((step) => (
                  <div
                    key={step.stepNumber}
                    className="p-5 rounded-2xl bg-slate-900/70 border border-slate-800 shadow-md flex items-start gap-4"
                  >
                    <div className="w-8 h-8 rounded-xl bg-purple-500/10 border border-purple-500/20 text-purple-300 flex items-center justify-center font-bold text-xs flex-shrink-0">
                      {step.stepNumber}
                    </div>

                    <div className="flex-1">
                      <div className="font-mono text-base font-bold text-purple-200 mb-1">
                        {step.expression}
                      </div>
                      <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                        {step.explanation}
                      </p>
                    </div>
                  </div>
                ))}
              </div>

              {/* Final Answer Banner */}
              <div className="p-6 rounded-3xl bg-gradient-to-r from-emerald-950/40 via-slate-900 to-purple-950/40 border-2 border-emerald-500/40 shadow-xl flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 block mb-1">
                    Yakuniy Javob:
                  </span>
                  <div className="text-2xl sm:text-3xl font-mono font-extrabold text-white">
                    {result.finalAnswer}
                  </div>
                </div>

                <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-300 text-xl font-bold">
                  ✓
                </div>
              </div>

              {/* Buttons: Yana tushuntir & Yangi masala */}
              <div className="flex flex-col sm:flex-row gap-3 pt-2">
                <button
                  onClick={() => setShowDeeperExplanation(!showDeeperExplanation)}
                  className="flex-1 py-3 px-4 rounded-2xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs sm:text-sm font-semibold flex items-center justify-center gap-2 transition-colors"
                >
                  <BookOpen className="w-4 h-4 text-purple-400" />
                  <span>Yana tushuntir</span>
                  {showDeeperExplanation ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </button>

                <button
                  onClick={() => {
                    setResult(null);
                    setImageSrc(null);
                    setProblemText('');
                  }}
                  className="py-3 px-5 rounded-2xl bg-purple-600 hover:bg-purple-500 text-white text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition-colors shadow-lg shadow-purple-600/20"
                >
                  <RefreshCw className="w-4 h-4" />
                  <span>Yangi masala</span>
                </button>
              </div>

              {/* Deeper explanation drawer */}
              {showDeeperExplanation && (
                <div className="p-5 rounded-2xl bg-slate-900 border border-purple-500/30 text-xs sm:text-sm text-slate-300 leading-relaxed animate-in fade-in duration-200">
                  <h4 className="font-bold text-white mb-2 flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-amber-400" />
                    <span>Batafsil tekshirish va mantiqiy asos:</span>
                  </h4>
                  <p>{result.deeperExplanation}</p>
                </div>
              )}

            </div>
          )}
        </div>

      </div>

    </div>
  );
};
