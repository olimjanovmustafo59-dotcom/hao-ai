import React from 'react';
import { 
  User, 
  X, 
  Sparkles, 
  ShieldCheck, 
  BarChart3, 
  Trash2, 
  Smartphone, 
  Languages, 
  CheckCircle2 
} from 'lucide-react';
import { historyService } from '../services/historyService';

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenHistory: () => void;
}

export const ProfileModal: React.FC<ProfileModalProps> = ({
  isOpen,
  onClose,
  onOpenHistory,
}) => {
  if (!isOpen) return null;

  const stats = historyService.getStats();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="w-full max-w-lg rounded-3xl bg-[#0f172a] border border-slate-800 shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Header */}
        <div className="p-6 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-purple-600 to-indigo-600 flex items-center justify-center text-white text-xl font-bold shadow-lg shadow-purple-600/30">
              U
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Foydalanuvchi Profili</h2>
              <p className="text-xs text-slate-400">AI Yordamchi — Professional Foydalanuvchi</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          
          {/* Quick Stats Grid */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-1.5">
              <BarChart3 className="w-4 h-4 text-purple-400" />
              <span>Sizning faolligingiz va statistikangiz:</span>
            </h3>

            <div className="grid grid-cols-2 gap-3">
              <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
                <span className="text-2xl font-extrabold text-white block">
                  {stats.historyCount}
                </span>
                <span className="text-xs text-slate-400">Saqlangan loyihalar</span>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
                <span className="text-2xl font-extrabold text-amber-400 block">
                  {stats.favoriteCount}
                </span>
                <span className="text-xs text-slate-400">Sevimli vositalar</span>
              </div>
            </div>
          </div>

          {/* Preferences */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-1 flex items-center gap-1.5">
              <Languages className="w-4 h-4 text-blue-400" />
              <span>Sozlamalar va til:</span>
            </h3>

            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 flex items-center justify-between">
              <div>
                <p className="text-xs font-bold text-white">Dastur tili</p>
                <p className="text-[11px] text-slate-400">O'zbek tili (Lotin alifbosi)</p>
              </div>
              <span className="text-xs font-semibold px-2.5 py-1 rounded-lg bg-emerald-500/10 text-emerald-300 border border-emerald-500/20">
                Faol ✓
              </span>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 flex items-center justify-between">
              <div>
                <p className="text-xs font-bold text-white">Xavfsizlik & Maxfiylik</p>
                <p className="text-[11px] text-slate-400">Fayllar faqat mahalliy brauzeringizda saqlanadi</p>
              </div>
              <ShieldCheck className="w-5 h-5 text-emerald-400" />
            </div>
          </div>

          {/* Buttons */}
          <div className="space-y-2 pt-2 border-t border-slate-800">
            <button
              onClick={() => {
                onClose();
                onOpenHistory();
              }}
              className="w-full py-3 px-4 rounded-2xl bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs sm:text-sm flex items-center justify-center gap-2 transition-colors shadow-lg shadow-purple-600/25"
            >
              <span>Tarixni to'liq ko'rish</span>
            </button>
          </div>

        </div>

      </div>
    </div>
  );
};
