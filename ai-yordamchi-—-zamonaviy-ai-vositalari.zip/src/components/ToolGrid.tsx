import React, { useState } from 'react';
import { 
  Star, 
  ArrowUpRight, 
  Sparkles, 
  SlidersHorizontal,
  Search
} from 'lucide-react';
import { ToolId, ToolMeta } from '../types';
import { TOOLS } from '../data/toolsData';

interface ToolGridProps {
  onSelectTool: (id: ToolId) => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  favorites: ToolId[];
  onToggleFavorite: (id: ToolId) => void;
}

export const ToolGrid: React.FC<ToolGridProps> = ({
  onSelectTool,
  searchQuery,
  onSearchChange,
  favorites,
  onToggleFavorite,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'favorites' | 'visual' | 'repair' | 'math' | 'utility' | 'video'>('all');

  const categories = [
    { id: 'all', label: 'Barcha vositalar' },
    { id: 'favorites', label: `⭐ Sevimlilar (${favorites.length})` },
    { id: 'visual', label: '📸 Rasm & Dizayn' },
    { id: 'repair', label: '🛠️ Maishiy & Ta\'mirlash' },
    { id: 'math', label: '🧮 Matematika & Fan' },
    { id: 'utility', label: '📱 Foydali vositalar' },
    { id: 'video', label: '🎬 Video & Ovoz' },
  ];

  const filteredTools = TOOLS.filter((tool) => {
    // Search filter
    const matchesSearch =
      tool.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tool.shortDesc.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tool.tags.some(t => t.toLowerCase().includes(searchQuery.toLowerCase()));

    // Category filter
    if (selectedCategory === 'favorites') {
      return matchesSearch && favorites.includes(tool.id);
    }
    if (selectedCategory !== 'all') {
      return matchesSearch && tool.category === selectedCategory;
    }

    return matchesSearch;
  });

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      
      {/* Title & Filter Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="w-2.5 h-2.5 rounded-full bg-purple-500 animate-ping" />
            <span className="text-xs font-semibold uppercase tracking-wider text-purple-400">
              AI Vositalar Markazi
            </span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
            Kerakli vositani tanlang
          </h2>
          <p className="text-slate-400 text-sm mt-1">
            Har bir vosita to'liq o'zbek tilida ishlaydi va yuqori aniqlikdagi AI algoritmlari bilan ta'minlangan.
          </p>
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-none max-w-full">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id as any)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap transition-all ${
                selectedCategory === cat.id
                  ? 'bg-purple-600 text-white shadow-lg shadow-purple-600/30'
                  : 'bg-slate-900/80 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Grid of Tool Cards */}
      {filteredTools.length === 0 ? (
        <div className="text-center py-16 px-4 bg-slate-900/40 rounded-3xl border border-slate-800/80 max-w-lg mx-auto">
          <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-purple-500/10 flex items-center justify-center text-2xl">
            🔍
          </div>
          <h3 className="text-lg font-bold text-white mb-2">Hech qanday vosita topilmadi</h3>
          <p className="text-sm text-slate-400 mb-6">
            "{searchQuery}" so'rovi bo'yicha vosita mavjud emas. Boshqa so'z bilan qidirib ko'ring yoki barcha vositalarni oching.
          </p>
          <button
            onClick={() => {
              onSearchChange('');
              setSelectedCategory('all');
            }}
            className="px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold"
          >
            Barcha vositalarni ko'rsatish
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 sm:gap-6">
          {filteredTools.map((tool) => {
            const isFav = favorites.includes(tool.id);

            return (
              <div
                key={tool.id}
                className="group relative flex flex-col justify-between p-6 sm:p-7 rounded-3xl bg-slate-900/70 border border-slate-800/80 hover:border-purple-500/40 transition-all duration-300 hover:shadow-2xl hover:shadow-purple-950/40 hover:-translate-y-1.5 backdrop-blur-md overflow-hidden cursor-pointer"
                onClick={() => onSelectTool(tool.id)}
              >
                {/* Background Subtle Gradient Glow */}
                <div className={`absolute top-0 right-0 w-36 h-36 bg-gradient-to-br ${tool.gradient} opacity-10 group-hover:opacity-20 blur-2xl transition-opacity pointer-events-none`} />

                <div>
                  {/* Top Bar with Icon & Favorite */}
                  <div className="flex items-start justify-between mb-5">
                    <div className="w-14 h-14 rounded-2xl bg-slate-800/80 border border-slate-700/60 flex items-center justify-center text-3xl shadow-inner group-hover:scale-110 group-hover:border-purple-500/40 transition-all duration-300">
                      {tool.icon}
                    </div>

                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onToggleFavorite(tool.id);
                        }}
                        className={`p-2 rounded-xl transition-all ${
                          isFav
                            ? 'text-amber-400 bg-amber-400/10 border border-amber-400/30'
                            : 'text-slate-400 hover:text-amber-300 bg-slate-800/50 hover:bg-slate-800 border border-slate-700/40'
                        }`}
                        title={isFav ? "Sevimlilardan o'chirish" : "Sevimlilarga qo'shish"}
                      >
                        <Star className={`w-4 h-4 ${isFav ? 'fill-amber-400' : ''}`} />
                      </button>

                      <div className="w-8 h-8 rounded-xl bg-slate-800/50 group-hover:bg-purple-600 text-slate-400 group-hover:text-white flex items-center justify-center transition-all duration-300">
                        <ArrowUpRight className="w-4 h-4 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
                      </div>
                    </div>
                  </div>

                  {/* Title & Description */}
                  <div className="mb-4">
                    <div className="inline-block text-[10px] font-bold uppercase tracking-wider text-purple-400 mb-1.5">
                      {tool.badge}
                    </div>
                    <h3 className="text-xl font-bold text-white group-hover:text-purple-300 transition-colors">
                      {tool.title}
                    </h3>
                    <p className="text-sm text-slate-400 mt-2 leading-relaxed">
                      {tool.shortDesc}
                    </p>
                  </div>
                </div>

                {/* Bottom Tags */}
                <div className="pt-4 border-t border-slate-800/60 flex flex-wrap gap-1.5">
                  {tool.tags.map((tag, idx) => (
                    <span
                      key={idx}
                      className="text-[11px] px-2.5 py-1 rounded-lg bg-slate-800/60 text-slate-400 group-hover:text-slate-300 border border-slate-700/40"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      )}

    </section>
  );
};
