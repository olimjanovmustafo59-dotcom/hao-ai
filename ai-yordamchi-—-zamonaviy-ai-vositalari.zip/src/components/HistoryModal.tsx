import React, { useState } from 'react';
import { 
  Clock, 
  Trash2, 
  FolderOpen, 
  RotateCcw, 
  ExternalLink, 
  X, 
  AlertCircle 
} from 'lucide-react';
import { historyService } from '../services/historyService';
import { HistoryItem, ToolId } from '../types';

interface HistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenItem: (item: HistoryItem) => void;
}

export const HistoryModal: React.FC<HistoryModalProps> = ({
  isOpen,
  onClose,
  onOpenItem,
}) => {
  const [historyList, setHistoryList] = useState<HistoryItem[]>(() => historyService.getHistory());
  const [filterTool, setFilterTool] = useState<string>('all');

  const refreshList = () => {
    setHistoryList(historyService.getHistory());
  };

  const handleDelete = (id: string) => {
    historyService.deleteHistory(id);
    refreshList();
  };

  const handleClearAll = () => {
    if (confirm("Haqiqatan ham barcha tarix ma'lumotlarini tozalashni xohlaysizmi?")) {
      historyService.clearHistory();
      refreshList();
    }
  };

  if (!isOpen) return null;

  const filtered = filterTool === 'all'
    ? historyList
    : historyList.filter(item => item.toolId === filterTool);

  const getToolBadge = (toolId: ToolId) => {
    switch (toolId) {
      case 'sticker':
        return { label: 'Sticker', color: 'bg-pink-500/20 text-pink-300 border-pink-500/30' };
      case 'object_detector':
        return { label: 'Bu nima?', color: 'bg-blue-500/20 text-blue-300 border-blue-500/30' };
      case 'repair':
        return { label: 'Ta\'mirlash', color: 'bg-amber-500/20 text-amber-300 border-amber-500/30' };
      case 'qrcode':
        return { label: 'QR Kod', color: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30' };
      case 'math':
        return { label: 'Matematika', color: 'bg-purple-500/20 text-purple-300 border-purple-500/30' };
      case 'subtitles':
        return { label: 'Subtitr', color: 'bg-rose-500/20 text-rose-300 border-rose-500/30' };
      default:
        return { label: 'AI Vosita', color: 'bg-slate-700 text-slate-300' };
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="w-full max-w-3xl max-h-[85vh] flex flex-col rounded-3xl bg-[#0f172a] border border-slate-800 shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Header */}
        <div className="p-6 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white">Foydalanish Tarixi (Tarix)</h2>
              <p className="text-xs text-slate-400">
                Siz yaratgan barcha stickerlar, tahlillar va loyihalar ro'yxati
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {historyList.length > 0 && (
              <button
                onClick={handleClearAll}
                className="px-3 py-1.5 rounded-xl bg-red-500/10 hover:bg-red-500/20 text-red-300 text-xs font-semibold border border-red-500/20 transition-colors"
              >
                Barchasini tozalash
              </button>
            )}

            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Filter bar */}
        <div className="px-6 py-3 bg-slate-900/60 border-b border-slate-800/80 flex items-center gap-2 overflow-x-auto scrollbar-none">
          {[
            { id: 'all', label: `Barchasi (${historyList.length})` },
            { id: 'sticker', label: '📸 Stickerlar' },
            { id: 'object_detector', label: '🔍 Obyektlar' },
            { id: 'repair', label: '🛠️ Ta\'mirlar' },
            { id: 'qrcode', label: '📱 QR Kodlar' },
            { id: 'math', label: '🧮 Masalalar' },
            { id: 'subtitles', label: '🎬 Subtitrlar' },
          ].map((f) => (
            <button
              key={f.id}
              onClick={() => setFilterTool(f.id)}
              className={`px-3 py-1 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
                filterTool === f.id
                  ? 'bg-purple-600 text-white'
                  : 'bg-slate-800/60 text-slate-400 hover:text-slate-200'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>

        {/* List Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-3">
          {filtered.length === 0 ? (
            <div className="text-center py-16 text-slate-400">
              <Clock className="w-12 h-12 mx-auto mb-3 text-slate-600 opacity-50" />
              <p className="text-sm font-semibold text-slate-300">Tarix hali bo'sh</p>
              <p className="text-xs text-slate-500 mt-1">
                AI vositalaridan birortasini ishlatganingizda, natijalar avtomatik ravishda bu yerda saqlanadi.
              </p>
            </div>
          ) : (
            filtered.map((item) => {
              const badge = getToolBadge(item.toolId);
              const dateStr = new Date(item.createdAt).toLocaleDateString('uz-UZ', {
                month: 'short',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
              });

              return (
                <div
                  key={item.id}
                  className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800/80 hover:border-slate-700 flex flex-col sm:flex-row sm:items-center justify-between gap-4 transition-colors"
                >
                  <div className="flex items-center gap-3.5">
                    {item.thumbnailUrl ? (
                      <img
                        src={item.thumbnailUrl}
                        alt="Thumbnail"
                        className="w-12 h-12 rounded-xl object-contain bg-black/40 border border-slate-800 flex-shrink-0"
                      />
                    ) : (
                      <div className="w-12 h-12 rounded-xl bg-slate-800 flex items-center justify-center text-lg flex-shrink-0">
                        📁
                      </div>
                    )}

                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${badge.color}`}>
                          {badge.label}
                        </span>
                        <span className="text-[11px] text-slate-500">{dateStr}</span>
                      </div>
                      <h4 className="text-sm font-bold text-white">{item.title}</h4>
                      {item.previewText && (
                        <p className="text-xs text-slate-400 line-clamp-1 mt-0.5">
                          {item.previewText}
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Action Buttons: Ochish, Qayta ishlash, O'chirish */}
                  <div className="flex items-center gap-2 self-end sm:self-center">
                    <button
                      onClick={() => {
                        onOpenItem(item);
                        onClose();
                      }}
                      className="px-3 py-1.5 rounded-xl bg-purple-600/20 hover:bg-purple-600/30 text-purple-300 border border-purple-500/30 text-xs font-semibold flex items-center gap-1 transition-colors"
                    >
                      <FolderOpen className="w-3.5 h-3.5" />
                      <span>Ochish</span>
                    </button>

                    <button
                      onClick={() => {
                        onOpenItem(item);
                        onClose();
                      }}
                      className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold flex items-center gap-1 transition-colors"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Qayta ishlash</span>
                    </button>

                    <button
                      onClick={() => handleDelete(item.id)}
                      className="p-1.5 rounded-xl bg-slate-800 hover:bg-red-500/20 text-slate-400 hover:text-red-400 transition-colors"
                      title="O'chirish"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>

      </div>
    </div>
  );
};
