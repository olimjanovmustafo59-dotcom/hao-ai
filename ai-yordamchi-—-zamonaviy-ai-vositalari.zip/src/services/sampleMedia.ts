// Sample base64 & SVG assets for instant 1-click demos
export const SAMPLE_IMAGES = {
  screwdriver: `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="500" height="500" viewBox="0 0 500 500"><rect width="500" height="500" fill="%231e293b"/><path d="M120 380 L220 280 L250 310 L150 410 Z" fill="%23e11d48"/><path d="M140 400 L160 420 L130 450 L110 430 Z" fill="%239f1239"/><path d="M220 280 L350 150 L380 180 L250 310 Z" fill="%2394a3b8"/><path d="M350 150 L390 110 L410 130 L370 170 Z" fill="%23cbd5e1"/><path d="M390 110 L420 80 L430 90 L400 120 Z" fill="%2338bdf8"/><text x="250" y="470" fill="%2394a3b8" font-family="sans-serif" font-size="20" text-anchor="middle">Otvyortka / Universal Asbob</text></svg>`,
  
  washingMachine: `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="500" height="500" viewBox="0 0 500 500"><rect width="500" height="500" fill="%230f172a"/><rect x="100" y="60" width="300" height="380" rx="20" fill="%23e2e8f0" stroke="%2394a3b8" stroke-width="6"/><rect x="120" y="80" width="120" height="40" rx="8" fill="%230284c7"/><circle cx="320" cy="100" r="18" fill="%2364748b"/><circle cx="360" cy="100" r="10" fill="%2310b981"/><circle cx="250" cy="270" r="110" fill="%23334155" stroke="%2364748b" stroke-width="12"/><circle cx="250" cy="270" r="85" fill="%230284c7" opacity="0.6"/><path d="M210 240 Q250 210 290 240 Q250 270 210 240" fill="%2338bdf8"/><rect x="330" y="400" width="50" height="30" rx="4" fill="%23475569"/><text x="250" y="475" fill="%2394a3b8" font-family="sans-serif" font-size="18" text-anchor="middle">Kir yuvish mashinasi (Drenaj muammosi)</text></svg>`,

  cuteCat: `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="500" height="500" viewBox="0 0 500 500"><rect width="500" height="500" fill="%23fdf4ff"/><circle cx="250" cy="260" r="130" fill="%23f59e0b"/><polygon points="150,180 180,90 220,160" fill="%23f59e0b"/><polygon points="160,170 180,110 210,160" fill="%23f43f5e"/><polygon points="350,180 320,90 280,160" fill="%23f59e0b"/><polygon points="340,170 320,110 290,160" fill="%23f43f5e"/><ellipse cx="205" cy="245" rx="16" ry="24" fill="%231e293b"/><ellipse cx="295" cy="245" rx="16" ry="24" fill="%231e293b"/><circle cx="210" cy="238" r="6" fill="%23ffffff"/><circle cx="300" cy="238" r="6" fill="%23ffffff"/><polygon points="250,270 240,285 260,285" fill="%23f43f5e"/><path d="M240 285 Q250 310 260 285" fill="none" stroke="%2378350f" stroke-width="4"/><path d="M160 280 L110 270 M160 290 L100 295 M340 280 L390 270 M340 290 L400 295" stroke="%2378350f" stroke-width="3"/></svg>`,

  mathFormula: `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="500" height="300" viewBox="0 0 500 300"><rect width="500" height="300" fill="%23ffffff" stroke="%23cbd5e1" stroke-width="4"/><text x="250" y="160" font-family="'JetBrains Mono', monospace" font-size="44" font-weight="bold" fill="%230f172a" text-anchor="middle">2x + 5 = 15</text><text x="250" y="240" font-family="sans-serif" font-size="18" fill="%2364748b" text-anchor="middle">Chiziqli algebraik tenglama</text></svg>`,
};

export const SAMPLE_MATH_PROBLEMS = [
  "2x + 5 = 15",
  "3x^2 - 12 = 0",
  "5x - 7 = 3x + 9",
  "320 ning 25% qismi qancha?",
  "Aylana radiusi r = 7 sm. Doira yuzasini toping (S = πr²)",
  "(x + 3)(x - 5) = 0"
];

export const SAMPLE_REPAIR_PROBLEMS = [
  { device: "Kir yuvish mashinasi", problem: "Suvi chiqmayapti, tsikl to'xtab qolyapti", icon: "🧺" },
  { device: "Smartfon", problem: "Batareya juda tez tugayapti va qizib ketmoqda", icon: "📱" },
  { device: "Muzlatgich / Sovutgich", problem: "Motor ishlayapti, lekin umuman sovitmayapti", icon: "❄️" },
  { device: "Velosiped", problem: "Zanjir uzilib ketgan va pedallar qattiq aylanmoqda", icon: "🚲" },
  { device: "Noutbuk", problem: "Ekran qora, faqat kuller ovozi eshitilyapti", icon: "💻" }
];
