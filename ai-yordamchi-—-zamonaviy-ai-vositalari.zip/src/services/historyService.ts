import { HistoryItem, ToolId } from '../types';

const HISTORY_KEY = 'ai_yordamchi_history';
const FAVORITES_KEY = 'ai_yordamchi_favorites';

export const historyService = {
  getHistory(): HistoryItem[] {
    try {
      const data = localStorage.getItem(HISTORY_KEY);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  addHistory(item: Omit<HistoryItem, 'id' | 'createdAt'>): HistoryItem {
    try {
      const current = this.getHistory();
      const newItem: HistoryItem = {
        ...item,
        id: 'hist_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
        createdAt: Date.now(),
      };
      const updated = [newItem, ...current].slice(0, 50); // keep last 50 items
      localStorage.setItem(HISTORY_KEY, JSON.stringify(updated));
      return newItem;
    } catch (e) {
      console.error('History save error:', e);
      return {
        ...item,
        id: 'temp_' + Date.now(),
        createdAt: Date.now(),
      };
    }
  },

  deleteHistory(id: string): void {
    try {
      const current = this.getHistory();
      const updated = current.filter(item => item.id !== id);
      localStorage.setItem(HISTORY_KEY, JSON.stringify(updated));
    } catch (e) {
      console.error('History delete error:', e);
    }
  },

  clearHistory(): void {
    try {
      localStorage.removeItem(HISTORY_KEY);
    } catch (e) {
      console.error('History clear error:', e);
    }
  },

  getFavorites(): ToolId[] {
    try {
      const data = localStorage.getItem(FAVORITES_KEY);
      return data ? JSON.parse(data) : ['sticker', 'math', 'qrcode']; // defaults
    } catch {
      return ['sticker', 'math', 'qrcode'];
    }
  },

  toggleFavorite(toolId: ToolId): boolean {
    try {
      const current = this.getFavorites();
      let updated: ToolId[];
      let isFav = false;
      if (current.includes(toolId)) {
        updated = current.filter(id => id !== toolId);
      } else {
        updated = [...current, toolId];
        isFav = true;
      }
      localStorage.setItem(FAVORITES_KEY, JSON.stringify(updated));
      return isFav;
    } catch {
      return false;
    }
  },

  isFavorite(toolId: ToolId): boolean {
    return this.getFavorites().includes(toolId);
  },

  getStats() {
    const hist = this.getHistory();
    const favs = this.getFavorites();
    const countsByTool: Record<string, number> = {};
    hist.forEach(h => {
      countsByTool[h.toolId] = (countsByTool[h.toolId] || 0) + 1;
    });

    return {
      historyCount: hist.length,
      favoriteCount: favs.length,
      countsByTool,
    };
  }
};
