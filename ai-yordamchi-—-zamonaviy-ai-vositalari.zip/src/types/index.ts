export type ToolId = 
  | 'sticker'
  | 'object_detector'
  | 'repair'
  | 'qrcode'
  | 'math'
  | 'subtitles';

export interface ToolMeta {
  id: ToolId;
  title: string;
  shortDesc: string;
  badge: string;
  icon: string;
  category: 'visual' | 'repair' | 'math' | 'utility' | 'video';
  tags: string[];
  gradient: string;
}

export interface ObjectAnalysisResult {
  objectName: string;
  usage: string;
  characteristics: string[];
  brandOrModel: string;
  interestingFact: string;
  safetyInfo: string;
  audioText: string;
}

export interface TroubleshootingStep {
  step: number;
  title: string;
  instruction: string;
}

export interface RepairResult {
  identifiedDevice: string;
  problemSummary: string;
  possibleCauses: string[];
  troubleshootingSteps: TroubleshootingStep[];
  toolsNeeded: string[];
  warning: string;
  isDangerous: boolean;
}

export interface MathStep {
  stepNumber: number;
  expression: string;
  explanation: string;
}

export interface MathResult {
  recognizedExpression: string;
  topic: string;
  steps: MathStep[];
  finalAnswer: string;
  deeperExplanation: string;
}

export interface SubtitleCue {
  id: number;
  start: string;
  end: string;
  text: string;
}

export interface SubtitleResult {
  videoName: string;
  detectedLanguage: string;
  duration: number;
  subtitles: SubtitleCue[];
  fullText: string;
}

export interface HistoryItem {
  id: string;
  toolId: ToolId;
  title: string;
  previewText?: string;
  thumbnailUrl?: string;
  createdAt: number;
  data: any;
}

export type StickerStyle = 'classic' | 'funny' | 'cartoon' | 'emoji' | 'minimal';

export interface StickerOverlayText {
  id: string;
  text: string;
  color: string;
  strokeColor: string;
  fontSize: number;
  x: number;
  y: number;
  rotation: number;
}

export interface StickerOverlayEmoji {
  id: string;
  emoji: string;
  size: number;
  x: number;
  y: number;
  rotation: number;
}
